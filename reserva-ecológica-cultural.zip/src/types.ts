export enum ScreenId {
  Génesis = "genesis",
  Metabolismo = "metabolismo",
  Senda = "senda",
  TejidoHumano = "tejidohumano"
}

export interface Myth {
  id: string;
  title: string;
  guardian: string;
  description: string;
  coordinates: string;
  wisdom: string;
  color: string;
}

export interface BioticCycle {
  id: string;
  name: string;
  status: "Óptimo" | "Fase de Ajuste" | "Crítico" | "Estable";
  value: number;
  unit: string;
  description: string;
  chemicalSymbol: string;
  nutrients: { name: string; percentage: number; color: string }[];
}

export interface Pavilion {
  id: string;
  name: string;
  volume: string;
  height: string;
  materials: { name: string; source: string; ratio: number }[];
  carbonOffset: string; // e.g. "-12.4 Ton Co2"
  description: string;
  blueprintImage: string;
}

export interface CommuneProfile {
  id: string;
  role: string;
  character: string;
  quote: string;
  schedule: { time: string; activity: string; impact: string }[];
  accentColor: string;
}
