import React, { useState, useEffect } from "react";
import { ScreenId } from "./types";
import Navbar from "./components/Navbar";
import InicioGenesis from "./components/InicioGenesis";
import InvestigacionMetabolismo from "./components/InvestigaciónMetabolismo";
import GaleriaSenda from "./components/GaleríaSenda";
import CulturaTejidoHumano from "./components/CulturaTejidoHumano";
import { Heart, Landmark, HelpCircle, Trees, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>(ScreenId.Génesis);

  // Scroll to top upon transition to ensure page context shifts
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [currentScreen]);

  // Support direct screen-routing based on hashtag if users share links
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash === "#genesis" || hash === "#inicio") {
        setCurrentScreen(ScreenId.Génesis);
      } else if (hash === "#investigacion" || hash === "#metabolismo") {
        setCurrentScreen(ScreenId.Metabolismo);
      } else if (hash === "#galeria" || hash === "#senda") {
        setCurrentScreen(ScreenId.Senda);
      } else if (hash === "#cultura" || hash === "#tejidohumano") {
        setCurrentScreen(ScreenId.TejidoHumano);
      }
    };

    window.addEventListener("hashchange", handleHashChange);
    handleHashChange(); // Trigger once on boot
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  const handleNavigate = (screen: ScreenId) => {
    setCurrentScreen(screen);
    // Update hash silently
    let newHash = "";
    if (screen === ScreenId.Génesis) newHash = "#genesis";
    else if (screen === ScreenId.Metabolismo) newHash = "#investigacion";
    else if (screen === ScreenId.Senda) newHash = "#galeria";
    else if (screen === ScreenId.TejidoHumano) newHash = "#cultura";
    window.history.pushState(null, "", newHash);
  };

  return (
    <div className="bg-moss-950 min-h-screen text-forest-100 font-sans selection:bg-bionic-green selection:text-moss-950">
      
      {/* Absolute top grid line overlay for technical style alignment */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.02] bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px] z-50" />

      {/* Persistent floating glass Navbar */}
      <Navbar currentScreen={currentScreen} onNavigate={handleNavigate} />

      {/* Screen Container with Framer Motion Push transitions */}
      <main className="relative mt-6 z-10">
        <AnimatePresence mode="wait">
          {currentScreen === ScreenId.Génesis && (
            <motion.div
              key="genesis"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              <InicioGenesis onNavigate={handleNavigate} />
            </motion.div>
          )}

          {currentScreen === ScreenId.Metabolismo && (
            <motion.div
              key="metabolismo"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              <InvestigacionMetabolismo />
            </motion.div>
          )}

          {currentScreen === ScreenId.Senda && (
            <motion.div
              key="senda"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              <GaleriaSenda />
            </motion.div>
          )}

          {currentScreen === ScreenId.TejidoHumano && (
            <motion.div
              key="tejidohumano"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              <CulturaTejidoHumano />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Persistent High Fidelity Footer */}
      <footer 
        id="persistent-app-footer"
        className="relative z-10 border-t border-forest-850 bg-radial from-[#0c1811] via-moss-950 to-moss-950 px-6 py-12 text-left"
      >
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <Trees className="w-5 h-5 text-bionic-green" />
              <span className="font-serif font-black text-white text-md uppercase tracking-wider">
                Reserva Ecológica Cultural Corazón
              </span>
            </div>
            <p className="text-xs text-forest-200 leading-relaxed max-w-sm">
              Un esfuerzo colectivo de soberanía alimentaria, arquitectura vernácula y bio-cibernética libre en defensa del sotobosque nativo y la memoria ancestral.
            </p>
          </div>

          <div className="md:col-span-3 space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Flujos del Sistema</h4>
            <div className="space-y-1">
              <button 
                id="footer-lnk-genesis"
                onClick={() => handleNavigate(ScreenId.Génesis)}
                className="block text-xs text-forest-200 hover:text-bionic-green transition-all"
              >
                Génesis — Inicio
              </button>
              <button 
                id="footer-lnk-metabolismo"
                onClick={() => handleNavigate(ScreenId.Metabolismo)}
                className="block text-xs text-forest-200 hover:text-bionic-green transition-all"
              >
                Metabolismo — Investigación
              </button>
              <button 
                id="footer-lnk-senda"
                onClick={() => handleNavigate(ScreenId.Senda)}
                className="block text-xs text-forest-200 hover:text-bionic-green transition-all"
              >
                Senda — Galería Arquitectónica
              </button>
              <button 
                id="footer-lnk-cultura"
                onClick={() => handleNavigate(ScreenId.TejidoHumano)}
                className="block text-xs text-forest-200 hover:text-bionic-green transition-all"
              >
                Tejido Humano — Cultura
              </button>
            </div>
          </div>

          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Gobernanza Libre</h4>
            <p className="text-[11px] text-forest-200 leading-relaxed">
              Consenso activo auditado diariamente. Todos los datos bioquímicos del micelio y los planos constructivos están licenciados bajo copyleft colectivo de asamblea soberana.
            </p>
            <div className="flex items-center gap-2 pt-1 text-[10px] font-mono text-bionic-amber">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-bionic-green animate-pulse" />
              CONECTADO A LA RED DE BIOMASA COMMUNE_V4
            </div>
          </div>
        </div>

        {/* Colectividad copyrights metadata */}
        <div className="max-w-6xl mx-auto border-t border-forest-850/40 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center text-[10px] font-mono text-forest-200">
          <div className="flex items-center gap-2">
            <Heart className="w-3.5 h-3.5 text-bionic-amber fill-bionic-amber" />
            <span>Regeneración Comunitaria Local Corazón 2026.</span>
          </div>
          <span className="mt-2 sm:mt-0">Licencia Libre de Código Abierto Común y Cooperativo</span>
        </div>
      </footer>
    </div>
  );
}
