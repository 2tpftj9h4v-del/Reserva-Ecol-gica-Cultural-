import React, { useState, useRef } from "react";
import { BioticCycle } from "../types";
import { Cpu, Zap, Gauge, LineChart, FileText, Download, Play, RefreshCw, BarChart2, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const CYCLES_DATA: BioticCycle[] = [
  {
    id: "cycle-1",
    name: "Red de Micelio",
    status: "Óptimo",
    value: 94,
    unit: "Hz de pulso eléctrico",
    description: "La actividad electroquímica fúngica pulsa vigorosamente. Las señales de intercambio de fósforo y carbono se desplazan a través de las micorrizas sin interferencia.",
    chemicalSymbol: "Myco-Fe",
    nutrients: [
      { name: "P (Fósforo)", percentage: 48, color: "bg-emerald-400" },
      { name: "C (Carbono)", percentage: 32, color: "bg-teal-400" },
      { name: "N (Nitrógeno)", percentage: 20, color: "bg-sky-400" }
    ]
  },
  {
    id: "cycle-2",
    name: "Caudal / Gradiente de Hidratación",
    status: "Fase de Ajuste",
    value: 81,
    unit: "m³/s caudal de cascadas",
    description: "Saturación hídrica regulada por las canopias naturales. El caudal capilar acusa ligeras oscilaciones por evaporación cíclica diurna.",
    chemicalSymbol: "H₂O",
    nutrients: [
      { name: "Hidrógeno", percentage: 66, color: "bg-blue-400" },
      { name: "Oxígeno disuelto", percentage: 24, color: "bg-cyan-400" },
      { name: "Silicio mineral", percentage: 10, color: "bg-indigo-300" }
    ]
  },
  {
    id: "cycle-3",
    name: "Eficiencia Lumínica / Fotosíntesis",
    status: "Óptimo",
    value: 89,
    unit: "% de captación cuántica",
    description: "La captación activa de fotones en el estrato medio alcanza niveles máximos bajo la configuración de las cúpulas geodésicas de mimbre ecológico.",
    chemicalSymbol: "CO₂-O₂",
    nutrients: [
      { name: "Clorofila-A", percentage: 55, color: "bg-green-400" },
      { name: "Carotenos", percentage: 25, color: "bg-amber-300" },
      { name: "Ficobilinas", percentage: 20, color: "bg-lime-400" }
    ]
  },
  {
    id: "cycle-4",
    name: "Captura de Carbono Atmosférico",
    status: "Estable",
    value: 74,
    unit: "PPM secuestradas/hr",
    description: "Compensación de CO₂ garantizada mediante plantaciones mixtas de Queñoa y Alerce en los contornos del pabellón principal.",
    chemicalSymbol: "C-offset",
    nutrients: [
      { name: "Biomasa leñosa", percentage: 60, color: "bg-amber-700" },
      { name: "Suelo húmico", percentage: 30, color: "bg-emerald-800" },
      { name: "Sustrato aéreo", percentage: 10, color: "bg-teal-500" }
    ]
  }
];

export default function InvestigacionMetabolismo() {
  const [activeCycle, setActiveCycle] = useState<BioticCycle>(CYCLES_DATA[0]);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationProgress, setSimulationProgress] = useState(0);

  // Sliders state for report generator
  const [reforestationRate, setReforestationRate] = useState(45);
  const [waterRecyclingRate, setWaterRecyclingRate] = useState(78);
  const [solarCookersActive, setSolarCookersActive] = useState(12);
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const cyclesRef = useRef<HTMLDivElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);

  // Start biotic cycles simulation
  const handleStartSimulation = () => {
    setIsSimulating(true);
    setSimulationProgress(0);
    const interval = setInterval(() => {
      setSimulationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsSimulating(false);
          // Slightly randomize current values to simulate dynamic updates
          activeCycle.value = Math.min(100, Math.max(60, activeCycle.value + Math.floor(Math.random() * 9) - 4));
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  // Helper to generate a custom impact report
  const generateImpactReport = () => {
    setIsGenerating(true);
    setGeneratedReport(null);
    setTimeout(() => {
      const co2Sequestration = (reforestationRate * 2.4).toFixed(1);
      const waterSaved = (waterRecyclingRate * 15.5).toFixed(0);
      const fuelAvoided = (solarCookersActive * 4.2).toFixed(1);
      const score = Math.round((reforestationRate * 0.4) + (waterRecyclingRate * 0.4) + (solarCookersActive * 1.6));

      const reportText = `REPORTE DE DIAGNÓSTICO METABÓLICO - RESERVA CORAZÓN
Firma Digital Colectiva: Corazón-OpenAudit v1.3

Parámetros Calibrados:
- Reforestación Activa: ${reforestationRate}% de la meta de la comuna
- Eficiencia Reciclaje Hídrico: ${waterRecyclingRate}% de captación de lluvia
- Cocinas Solares en Operación: ${solarCookersActive} Unidades Activas

Impacto Estimado Resultante:
1) Secuestro Adicional CO₂: ${co2Sequestration} Toneladas métricas / año.
2) Conservación del Acuífero: ${waterSaved} Litros recuperados diariamente de escorrentías.
3) Mitigación de Deforestación: ${fuelAvoided} kg de biomasa seca no combustionada por semana.

ÍNDICE DE EFICIENCIA COMUNAL INTEGRAL: ${score}% (${score > 80 ? "Soberanía Tipo-A (Plena)" : "Soberanía Tipo-B (Estabilidad Transitoria)"})`;
      
      setGeneratedReport(reportText);
      setIsGenerating(false);
    }, 1500);
  };

  const scrollToCycles = () => {
    cyclesRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToReport = () => {
    reportRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div id="screen-metabolismo" className="min-h-screen text-forest-50 select-none pb-24">
      {/* Bio-Cybernetic Landing Hero */}
      <div className="relative h-[65vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            id="metabolismo-hero-img"
            src="https://lh3.googleusercontent.com/aida/AP1WRLupPsDTkd26RRvkD9z5V_eLr1KCKg0PSZpDqp0PU-vxXw9C74P01YB7pNfLvHALHnJNNmHmjaXWKJnuRJp3njmrmgV5Ys8WzLQQJP4fn1VQV8UVf7JVEWyddsuCqUMbTGlH_JTATVEpBzFKcoaiQFeCOdS8dakAevUlr4T2qD94wj5B5ASDFxG6Ogd610N9ThBDTpvDH9gmD_jlIoNmi7u0hoPkqIMItse26XN_A2UQ2dMB75jQ14Bwvfk"
            alt="Laboratorio de Metabolismo"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-moss-950 via-moss-950/80 to-moss-950/40" />
        </div>

        {/* Hero Core Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-moss-950 border border-bionic-green/30 rounded-full text-[10px] font-mono tracking-widest text-bionic-green uppercase mb-6 shadow-xl">
            <Cpu className="w-3.5 h-3.5" />
            Monitoreo Biótico en Tiempo Real
          </div>
          <h1 
            id="metabolismo-heading"
            className="text-4xl md:text-6xl font-serif font-black tracking-tight text-white mb-4 uppercase"
          >
            Metabolismo Cíclico
          </h1>
          <p className="text-forest-100 font-sans font-light text-sm md:text-lg max-w-2xl mx-auto leading-relaxed mb-8">
            Decodificamos los lenguajes químicos de las raíces, flujos capilares y capturas bioquímicas para optimizar la simbiosis entre el colectivo humano y el bosque nativo.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              id="btn-trigger-analizar-ciclos"
              onClick={scrollToCycles}
              className="px-6 py-3.5 bg-forest-800 hover:bg-forest-600 border border-bionic-green/40 hover:border-bionic-green rounded-full font-semibold text-xs tracking-wider text-bionic-green hover:text-white transition-all flex items-center gap-2 cursor-pointer uppercase"
            >
              <Zap className="w-4 h-4 text-bionic-green" />
              Analizar Ciclos
            </button>
            <button
              id="btn-trigger-reporte-impacto"
              onClick={scrollToReport}
              className="px-6 py-3.5 bg-bionic-amber hover:bg-amber-400 text-moss-950 font-bold rounded-full text-xs tracking-wider transition-all flex items-center gap-2 cursor-pointer uppercase shadow-lg shadow-amber-950/20"
            >
              <FileText className="w-4 h-4" />
              Reporte de Impacto
            </button>
          </div>
        </div>
      </div>

      {/* Holographic Dome Structure showcase section */}
      <div className="max-w-6xl mx-auto px-6 mt-12 mb-16">
        <div className="bg-forest-900/30 border border-forest-800/60 p-6 md:p-10 rounded-3xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-radial from-forest-900/40 to-transparent">
          <div className="lg:col-span-4 relative flex justify-center">
            <div className="relative p-2.5 bg-moss-950 border border-forest-800 rounded-3xl overflow-hidden shadow-2xl">
              <img 
                id="dome-hologram-img"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuC_-J3X5qCfG3grSWzc9a9XIqBwFX1DY5IzvP0a31P1JB-MdIMNh4P27B54W-5Vioo0WU6Na6YVv3oYryy1UhB38nMYW0JmsNi6hXiOLH8iOSp_B1uMxJ8-uHy5S79ciannQ0Vl261tXb8y4IzBNIS38U3GGXLsyR4rRNv3VMyL9jD5UtPm4AicGWuZBp5lvvrPZNz8S4llluncZozdiCwKJkoF9kPX59f_8xWHlW0IYmTzAs3ItZRjnBB5unoTbwt4clIoh_PMQhA" 
                alt="Estructura Holográfica de Mimbre"
                className="w-64 h-64 md:w-72 md:h-72 object-cover rounded-2xl border border-forest-800/80"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-4 left-4 bg-moss-950/90 border border-bionic-green/40 p-2 rounded text-[9px] font-mono text-bionic-green uppercase tracking-wide">
                Cúpula Mimbral v4.0
              </div>
            </div>
          </div>
          <div className="lg:col-span-8 space-y-4 text-left">
            <span className="text-[10px] font-mono text-bionic-amber uppercase tracking-wider block">// Estructuras Simbióticas</span>
            <h3 className="text-2xl md:text-3xl font-serif font-bold text-white uppercase leading-tight">
              Cúpula Tecnológica del Bosque Profundo
            </h3>
            <p className="text-forest-100 font-sans text-xs md:text-sm font-light leading-relaxed">
              Ubicado en el epicentro de la Reserva, este domo arquitectónico utiliza mimbre entrelazado y bio-cemento celular para canalizar ventilaciones térmicas pasivas. Alberga nuestro sistema modular de servidores de baja inducción magnética, alimentados enteramente por microgeneradores hidráulicos situados en las cascadas superiores. Un tributo de diseño donde la ingeniería cibernética se integra armónicamente en el sustrato vivo.
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              <div className="text-left">
                <span className="block text-[10px] font-mono text-forest-200">Material de Soporte</span>
                <span className="text-xs font-mono font-bold text-bionic-green">Mimbre + Micelio Sólido</span>
              </div>
              <div className="w-px h-8 bg-forest-800 self-center" />
              <div className="text-left">
                <span className="block text-[10px] font-mono text-forest-200">Enfriamiento Biotérmico</span>
                <span className="text-xs font-mono font-bold text-bionic-green">94% Pasivo por Capilaridad</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* The 3 Metric Cards representing Biological Telemetry */}
      <div className="max-w-6xl mx-auto px-6 mb-20">
        <h2 className="text-xl md:text-2xl font-serif font-black text-white text-left uppercase mb-8 flex items-center gap-2">
          <Gauge className="w-5 h-5 text-bionic-green" />
          Monitoreo y Sensores Ambientales
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Mycelium Networks */}
          <div className="bg-gradient-to-b from-forest-900/40 to-moss-950 border border-forest-800/80 rounded-3xl p-5 hover:border-bionic-green/40 transition-colors flex flex-col justify-between">
            <div>
              <div className="relative rounded-2xl overflow-hidden mb-4 h-48 border border-forest-800">
                <img 
                  id="metric-img-micelio"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAgW1IQrXjdFNMEqgIMBrhbJ0BvICxQ3gdwpcaSehbeof-wXjLaEduGRnwnHtMOPf1JnXjCk4lX6XBRO2e8dpSOgeteD_FwdgIbatBLl85bwhB6lARKPQdheWNn8HbIbNvsUZfZgh27g7ziR2YyIoBPijN5XfuuqWxlgcJHW1CdrJ8v2IcoJvkEzhtQTiZbwGL4zw4donB5awsdBRzzGw1Y8eWzItsRutnqnjlN7NP-dt-IpJUHQup2kx7YaGXKQwMl7oYg96rfWkA" 
                  alt="Redes de Micelio" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 bg-moss-950/90 border border-bionic-green/45 rounded px-2 py-0.5 text-[9px] font-mono text-bionic-green">
                  PulseNode-M12
                </span>
              </div>
              <h3 className="font-serif font-bold text-white text-lg mb-1 uppercase">Redes de Micelio</h3>
              <p className="text-xs text-forest-100 font-sans leading-relaxed">
                Nuestros biosensores no invasivos captan las señales de infoquímicos intercambiados entre las raíces de árboles antiguos que gestionan la resiliencia microgástral.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-forest-800/40 flex justify-between items-center">
              <span className="text-[10px] font-mono text-forest-200">SALUD MICÓTICA</span>
              <span className="text-xs font-mono font-semibold text-bionic-green">94% COOPERATIVA</span>
            </div>
          </div>

          {/* Card 2: Hydration Flow Gradient */}
          <div className="bg-gradient-to-b from-forest-900/40 to-moss-950 border border-forest-800/80 rounded-3xl p-5 hover:border-bionic-green/40 transition-colors flex flex-col justify-between">
            <div>
              <div className="relative rounded-2xl overflow-hidden mb-4 h-48 border border-forest-800">
                <img 
                  id="metric-img-hidratacion"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuC177FKNLPbN3hgaqmXvtHw8nxrsHMwyBSTPS8WcL-aPp8z0mC05AEnfKGkWT1ZaTIFD7W0pFOUC-uBON1Ca-iwbXxDDkJsRuu11O6HzNItQUMHzNDZ6_nVAhH1ESqOFDU1g0rMOoKuDLv6JO8YMcFsukfp6GYx6_MlPu4tb68J3aok2ZfIXYAki1p1iQLapdmZnSwxdJGhzPerI6mVnh095LyM74gWAdpvsxe7LwIHf6BkuDjSo_gQCgSRAnv750LsRDwengV7qPM" 
                  alt="Gradiente de Hidratación" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 bg-moss-950/90 border border-blue-400/45 rounded px-2 py-0.5 text-[9px] font-mono text-blue-400">
                  HydroFlow-W09
                </span>
              </div>
              <h3 className="font-serif font-bold text-white text-lg mb-1 uppercase">Gradiente de Hidratación</h3>
              <p className="text-xs text-forest-100 font-sans leading-relaxed">
                Monitorea la escorrentía freática y el flujo de capilaridad forestal que previene la desecación del sotobosque, asegurando reservas equilibradas en la cuenca.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-forest-800/40 flex justify-between items-center">
              <span className="text-[10px] font-mono text-forest-200">FLUJO CAPILAR</span>
              <span className="text-xs font-mono font-semibold text-blue-400">81.2 L/S FLUIDEZ</span>
            </div>
          </div>

          {/* Card 3: Photo Efficiency */}
          <div className="bg-gradient-to-b from-forest-900/40 to-moss-950 border border-forest-800/80 rounded-3xl p-5 hover:border-bionic-green/40 transition-colors flex flex-col justify-between">
            <div>
              <div className="relative rounded-2xl overflow-hidden mb-4 h-48 border border-forest-800">
                <img 
                  id="metric-img-luminico"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuD0ai3JEBdCWmuBu7DM_jaDhIcwDxG3gUX-WbDpEfyYykI4jaUjuw0zUjJ4W2B0vV7P94twHER5_c9tfUywvg4-8Bgad5pNaD_KxqBuxsOTxGPXAgbjEszW2s06WxDRFwUqFfTCuvpPqGs0s-viA0aDs3uibcxbN-u0Jck9-NDcP6dzataIEbTD1Aals6rJopdzQ58eygFHqRnLOqFc-NKjFtKIwTO8v8JATYCDcMi2Y2f8mJoTiKXONiBKz64OZpYGz84RbEy-Pxs" 
                  alt="Eficiencia Lumínica" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 bg-moss-950/90 border border-bionic-amber/45 rounded px-2 py-0.5 text-[9px] font-mono text-bionic-amber">
                  LightSpect-L4
                </span>
              </div>
              <h3 className="font-serif font-bold text-white text-lg mb-1 uppercase">Eficiencia Lumínica</h3>
              <p className="text-xs text-forest-100 font-sans leading-relaxed">
                Análisis espectral volumétrico de la penetración cuántica de la luz solar en las hojas, optimizando la regeneración arbórea en zonas densas.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-forest-800/40 flex justify-between items-center">
              <span className="text-[10px] font-mono text-forest-200">CAPTURA FOTÓNICA</span>
              <span className="text-xs font-mono font-semibold text-bionic-amber">89% COMPROBADO</span>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION: ANALIZAR CICLOS */}
      <div 
        id="cycles-analyzer-section"
        ref={cyclesRef}
        className="max-w-6xl mx-auto px-6 border-t border-forest-800/50 pt-16 mb-20"
      >
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[10px] font-mono text-bionic-green uppercase tracking-widest block mb-2">
            // Consola de Simulación Operativa
          </span>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-white uppercase">
            Analizar Ciclos Bioquímicos
          </h2>
          <p className="text-forest-100 font-sans font-light text-sm mt-2">
            Ejecuta diagnósticos sobre los flujos del sustrato y descubre la distribución interna de nutrientes catalizada por el micelio y el sol.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-8 bg-moss-950/80 p-2 border border-forest-800/80 rounded-2xl">
          {CYCLES_DATA.map((cycle) => (
            <button
              id={`cycle-tab-${cycle.id}`}
              key={cycle.id}
              onClick={() => {
                setActiveCycle(cycle);
                // Reset simulation progress if picking another
                setSimulationProgress(0);
              }}
              className={`p-3 rounded-xl text-left transition-all duration-300 ${
                activeCycle.id === cycle.id 
                  ? "bg-forest-800 border border-bionic-green/40 text-white" 
                  : "text-forest-100 hover:text-bionic-green hover:bg-forest-900/40"
              }`}
            >
              <span className="block text-[10px] font-mono text-bionic-green">{cycle.chemicalSymbol}</span>
              <span className="block text-xs font-bold truncate mt-0.5 uppercase">{cycle.name}</span>
            </button>
          ))}
        </div>

        {/* Interactive Simulation Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Cycle Metrics Details */}
          <div className="lg:col-span-7 bg-forest-900/20 border border-forest-800/80 rounded-3xl p-6 md:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-[10px] font-mono text-forest-200 tracking-wider uppercase">Ciclo Activo</span>
                  <h3 className="text-2xl font-serif font-bold text-white uppercase mt-0.5">{activeCycle.name}</h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono block text-forest-200 uppercase">Estado</span>
                  <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold mt-1 ${
                    activeCycle.status === "Óptimo" 
                      ? "bg-emerald-950 border border-bionic-green text-bionic-green" 
                      : activeCycle.status === "Estable" 
                      ? "bg-forest-950 border border-forest-600/60 text-forest-100" 
                      : "bg-amber-950 border border-bionic-amber text-bionic-amber"
                  }`}>
                    {activeCycle.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="p-4 bg-moss-950 border border-forest-800 rounded-2xl text-center">
                  <span className="text-[10px] font-mono text-forest-200 block uppercase">Nivel Actual</span>
                  <span className="text-3xl font-mono text-emerald-300 font-bold tracking-tight block mt-1">
                    {activeCycle.value}%
                  </span>
                  <span className="text-[9px] font-mono text-forest-100 mt-1 block">
                    {activeCycle.unit}
                  </span>
                </div>
                <div className="p-4 bg-moss-950 border border-forest-800 rounded-2xl text-center flex flex-col justify-center">
                  <span className="text-[10px] font-mono text-forest-200 block uppercase">Clasificación Orgánica</span>
                  <span className="text-sm font-sans font-black text-white mt-2 block">
                    {activeCycle.chemicalSymbol} Activo
                  </span>
                </div>
              </div>

              <p className="text-forest-100 font-sans text-xs md:text-sm font-light leading-relaxed mb-6">
                {activeCycle.description} La monitorización de este flujo aporta información crucial para la toma de decisiones ecológicas en las asambleas de la comuna.
              </p>

              {/* Nutrients percentages */}
              <div className="space-y-3">
                <span className="text-[10px] font-mono text-forest-200 uppercase tracking-widest block">Composición Fisiológica Relativa</span>
                {activeCycle.nutrients.map((n, i) => (
                  <div key={i} className="text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-sans font-medium text-white">{n.name}</span>
                      <span className="font-mono text-forest-100">{n.percentage}%</span>
                    </div>
                    <div className="w-full bg-moss-950 h-2 rounded-full overflow-hidden border border-forest-850">
                      <div className={`h-full ${n.color}`} style={{ width: `${n.percentage}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Action simulation trigger */}
            <div className="mt-8 pt-6 border-t border-forest-800/40 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                id="btn-ejecutar-simulacion"
                disabled={isSimulating}
                onClick={handleStartSimulation}
                className="w-full sm:w-auto px-6 py-3 bg-bionic-green hover:bg-bionic-light text-moss-950 font-bold rounded-full text-xs tracking-wider uppercase transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-55"
              >
                {isSimulating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-moss-950" />
                    Analizando...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 text-moss-950 fill-moss-950" />
                    Ejecutar Simulación
                  </>
                )}
              </button>
              {isSimulating && (
                <div className="w-full sm:w-2/3">
                  <div className="flex justify-between text-[10px] font-mono text-bionic-green mb-1">
                    <span>Muestreando microvibraciones fúngicas...</span>
                    <span>{simulationProgress}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-forest-900 border border-forest-800 rounded-full overflow-hidden">
                    <div className="h-full bg-bionic-green" style={{ width: `${simulationProgress}%` }} />
                  </div>
                </div>
              )}
              {!isSimulating && simulationProgress === 100 && (
                <span className="text-[10px] font-mono text-bionic-green flex items-center gap-1">
                  <span className="w-2 h-2 bg-bionic-green rounded-full animate-ping" />
                  Calibración Completa exitosa.
                </span>
              )}
            </div>
          </div>

          {/* Graphical Node Feed (Interactive Visual Simulation representing cybernetic feedback block) */}
          <div className="lg:col-span-5 bg-moss-950 border border-forest-800/80 rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute inset-0 bg-radial from-emerald-900/10 to-transparent pointer-events-none" />
            <div>
              <div className="flex items-center gap-2 mb-4">
                <LineChart className="w-4 h-4 text-bionic-green" />
                <span className="text-[10px] font-mono text-bionic-green uppercase tracking-wide">Representación Vectorial de Nodos</span>
              </div>
              <p className="text-[11px] text-forest-100 font-sans leading-relaxed mb-4">
                Representación viva de la retroalimentación molecular entre sensores. Los flujos de pulso de luz demuestran traspasos bioeléctricos de información.
              </p>

              {/* Gorgeous SVG interactive map resembling mycorrhizal network flow */}
              <div className="border border-forest-850 bg-radial from-forest-950 to-moss-950 h-56 rounded-2xl relative overflow-hidden flex items-center justify-center">
                <svg className="w-full h-full p-4" viewBox="0 0 300 200">
                  {/* Connection lines */}
                  <line x1="50" y1="50" x2="150" y2="100" stroke="#10b981" strokeWidth="1" strokeDasharray="3,3" opacity="0.6" />
                  <line x1="250" y1="50" x2="150" y2="100" stroke="#10b981" strokeWidth="1" opacity="0.4" />
                  <line x1="150" y1="100" x2="150" y2="170" stroke="#fbbf24" strokeWidth="1.5" strokeDasharray="4,2" opacity="0.8" />
                  <line x1="50" y1="50" x2="150" y2="170" stroke="#34d399" strokeWidth="1" opacity="0.3" strokeDasharray="2,5" />

                  {/* Pulsing highlights */}
                  {isSimulating && (
                    <>
                      <circle cx="100" cy="75" r="3" fill="#34d399">
                        <animate attributeName="cx" values="50;150" dur="2s" repeatCount="indefinite" />
                        <animate attributeName="cy" values="50;100" dur="2s" repeatCount="indefinite" />
                      </circle>
                      <circle cx="150" cy="135" r="4" fill="#fbbf24">
                        <animate attributeName="cy" values="100;170" dur="1.5s" repeatCount="indefinite" />
                      </circle>
                    </>
                  )}

                  {/* Nodes */}
                  <g className="cursor-pointer">
                    <circle cx="50" cy="50" r="12" fill="#0b140e" stroke="#34d399" strokeWidth="2" />
                    <text x="50" y="54" fontSize="8" fill="#34d399" textAnchor="middle" fontFamily="monospace">N1</text>
                  </g>
                  <g className="cursor-pointer">
                    <circle cx="250" cy="50" r="12" fill="#0b140e" stroke="#10b981" strokeWidth="2" />
                    <text x="250" y="54" fontSize="8" fill="#10b981" textAnchor="middle" fontFamily="monospace">N2</text>
                  </g>
                  <g className="cursor-pointer">
                    <circle cx="150" cy="100" r="16" fill="#0b140e" stroke="#34d399" strokeWidth="3" className="animate-[pulse_2s_infinite]" />
                    <text x="150" y="104" fontSize="9" fill="#fff" textAnchor="middle" fontFamily="monospace" fontWeight="bold">HQ</text>
                  </g>
                  <g className="cursor-pointer">
                    <circle cx="150" cy="170" r="10" fill="#0b140e" stroke="#fbbf24" strokeWidth="2" />
                    <text x="150" y="174" fontSize="8" fill="#fbbf24" textAnchor="middle" fontFamily="monospace">T3</text>
                  </g>

                  {/* Legend overlay inside SVG */}
                  <text x="10" y="190" fontSize="7" fill="#6ee7b7" fontFamily="monospace">RED COMPLETA: REGULADA</text>
                </svg>
              </div>
            </div>

            <div className="mt-4 p-3 bg-forest-900/40 rounded-xl border border-forest-800/40 flex items-center justify-between">
              <div>
                <span className="block text-[8px] font-mono text-forest-200">FRECUENCIA PRINCIPAL</span>
                <span className="text-xs font-mono font-bold text-white">432.18 MHz</span>
              </div>
              <span className="inline-block px-1.5 py-0.5 rounded text-[8px] font-mono bg-emerald-950 text-bionic-green border border-bionic-green/20 uppercase tracking-widest">
                Sincronía Armónica
              </span>
            </div>
          </div>

        </div>
      </div>

      {/* SECTION: REPORTE DE IMPACTO (Interactive sliding parameters generator) */}
      <div 
        id="carbon-impact-report-section"
        ref={reportRef}
        className="max-w-6xl mx-auto px-6 border-t border-forest-800/50 pt-16"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Sliders Control Panel */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="text-[10px] font-mono text-bionic-amber uppercase tracking-widest block mb-1">
                // Auditoría y Transparencia
              </span>
              <h2 className="text-3xl font-serif font-black text-white uppercase mb-2">
                Generador de Reporte de Impacto
              </h2>
              <p className="text-xs text-forest-100 font-sans leading-relaxed">
                Modifica los indicadores colectivos de la Comuna ecológicamente planificados para evaluar las tasas de impacto ambiental de la reserva.
              </p>
            </div>

            {/* Slider 1: Reforestation */}
            <div className="p-4 bg-forest-900/30 border border-forest-800/40 rounded-2xl">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-white uppercase">Meta de Reforestación Activa</label>
                <span className="text-xs font-mono font-black text-bionic-green">{reforestationRate}%</span>
              </div>
              <input 
                id="slider-reforestation"
                type="range" 
                min="10" 
                max="100" 
                value={reforestationRate}
                onChange={(e) => setReforestationRate(Number(e.target.value))}
                className="w-full accent-bionic-green bg-moss-950 rounded-lg cursor-pointer h-1"
              />
              <span className="text-[9px] font-mono text-forest-200 block mt-1">Especies plantadas: canelo, arrayán, queñoa nativa.</span>
            </div>

            {/* Slider 2: Water cap */}
            <div className="p-4 bg-forest-900/30 border border-forest-800/40 rounded-2xl">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-white uppercase">Reciclaje e Absorción Hídrica</label>
                <span className="text-xs font-mono font-black text-bionic-green">{waterRecyclingRate}%</span>
              </div>
              <input 
                id="slider-water-recycling"
                type="range" 
                min="20" 
                max="100" 
                value={waterRecyclingRate}
                onChange={(e) => setWaterRecyclingRate(Number(e.target.value))}
                className="w-full accent-bionic-green bg-moss-950 rounded-lg cursor-pointer h-1"
              />
              <span className="text-[9px] font-mono text-forest-200 block mt-1">Capacidad de captación de aguas pluviales en cuencas.</span>
            </div>

            {/* Slider 3: solar modules */}
            <div className="p-4 bg-forest-900/30 border border-forest-800/40 rounded-2xl">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-white uppercase">Cocinas Solares Operativas</label>
                <span className="text-xs font-mono font-black text-bionic-amber">{solarCookersActive} unidades</span>
              </div>
              <input 
                id="slider-solar-cookers"
                type="range" 
                min="0" 
                max="30" 
                value={solarCookersActive}
                onChange={(e) => setSolarCookersActive(Number(e.target.value))}
                className="w-full accent-bionic-amber bg-moss-950 rounded-lg cursor-pointer h-1"
              />
              <span className="text-[9px] font-mono text-forest-200 block mt-1">Módulos parabólicos en la comuna para alimentación sustentable.</span>
            </div>

            <button
              id="btn-generar-reporte-diagnostico"
              onClick={generateImpactReport}
              disabled={isGenerating}
              className="w-full py-4.5 bg-bionic-green hover:bg-bionic-light text-moss-950 font-extrabold rounded-full text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-55 shadow-lg shadow-emerald-900/20"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Estructurando Diagnóstico...
                </>
              ) : (
                <>
                  <BarChart2 className="w-4 h-4" />
                  Generar Reporte de Impacto
                </>
              )}
            </button>
          </div>

          {/* Report output console */}
          <div className="lg:col-span-7">
            <div className="backdrop-blur-md bg-moss-950 border border-forest-800/80 rounded-3xl p-6 relative overflow-hidden flex flex-col justify-between h-full min-h-[460px]">
              
              {/* Terminal Header */}
              <div className="flex items-center justify-between border-b border-forest-850 pb-4 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/40" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/40" />
                  <div className="w-3 h-3 rounded-full bg-green-500/40" />
                  <span className="text-[10px] font-mono text-forest-200 ml-2">Console: impact_diagnostic_service.sh</span>
                </div>
                <span className="text-[9px] font-mono text-bionic-green uppercase tracking-wider">
                  Sovereignty Audit
                </span>
              </div>

              {/* Console Body */}
              <div className="flex-1 font-mono text-xs text-emerald-100 flex items-center justify-center bg-radial from-forest-950/20 to-transparent p-4 min-h-[300px]">
                <AnimatePresence mode="wait">
                  {isGenerating ? (
                    <motion.div 
                      key="generating"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="text-center space-y-4"
                    >
                      <RefreshCw className="w-8 h-8 animate-spin text-bionic-green mx-auto" />
                      <div className="space-y-1">
                        <p className="text-xs text-bionic-green">Calculando huella de carbono y offsets de madera...</p>
                        <p className="text-[10px] text-forest-200">Iteración Bayesiana activa para amortiguación de CO₂</p>
                      </div>
                    </motion.div>
                  ) : generatedReport ? (
                    <motion.div
                      key="result"
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="w-full text-left bg-forest-950/60 p-5 border border-forest-800 rounded-2xl whitespace-pre-wrap leading-relaxed select-text"
                    >
                      {generatedReport}
                    </motion.div>
                  ) : (
                    <motion.div
                      key="initial"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-center max-w-sm space-y-3"
                    >
                      <FileText className="w-12 h-12 text-forest-200 opacity-60 mx-auto" />
                      <p className="text-xs text-forest-200">
                        Por favor calibra los parámetros de la comuna a la izquierda y presiona el botón para procesar el reporte metabólico.
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Terminal Footer */}
              {generatedReport && !isGenerating && (
                <div className="border-t border-forest-850 pt-4 mt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <span className="text-[9px] font-mono text-forest-200 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-bionic-green" />
                    Reporte firmado digitalmente por la Comuna Corazón
                  </span>
                  
                  <button
                    id="btn-imprimir-reporte-impacto"
                    onClick={() => {
                      alert("Kit de impresión ecológica activado en simulación. Descarga de reporte en formato libre completo.");
                    }}
                    className="w-full sm:w-auto px-4 py-2 bg-forest-800 border border-forest-600 hover:border-bionic-green text-[10px] font-mono tracking-widest text-bionic-green hover:text-white rounded-full transition-all flex items-center justify-center gap-1.5 cursor-pointer uppercase"
                  >
                    <Download className="w-3 h-3" />
                    Descargar Copia (.TXT)
                  </button>
                </div>
              )}

            </div>
          </div>
          
        </div>
      </div>
      
    </div>
  );
}
