import React from "react";
import { ScreenId } from "../types";
import { Trees, Compass, Cpu, Landmark, Users } from "lucide-react";

interface NavbarProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

export default function Navbar({ currentScreen, onNavigate }: NavbarProps) {
  return (
    <nav 
      id="main-nav-bar"
      className="sticky top-4 z-50 mx-auto max-w-6xl px-4"
    >
      <div className="backdrop-blur-md bg-moss-950/80 border border-forest-800/60 rounded-full px-4 md:px-8 py-3.5 flex items-center justify-between shadow-2xl shadow-emerald-950/20">
        
        {/* Logo and Brand */}
        <button 
          id="nav-logo-btn"
          onClick={() => onNavigate(ScreenId.Génesis)}
          className="flex items-center gap-2.5 group text-left focus:outline-none"
        >
          <div className="bg-forest-900 border border-bionic-green/40 p-2 rounded-full group-hover:scale-105 group-hover:border-bionic-green transition-all duration-300">
            <Trees className="w-5 h-5 text-bionic-green animate-pulse" />
          </div>
          <div>
            <span className="block font-serif font-bold text-xs tracking-wider text-forest-50 select-none uppercase">
              Reserva Ecológica
            </span>
            <span className="block font-sans text-[10px] tracking-widest text-bionic-green/80 font-medium uppercase">
              Cultural Corazón
            </span>
          </div>
        </button>

        {/* Navigation Anchors/Links */}
        <div className="flex items-center gap-1 md:gap-4">
          <a
            id="nav-link-genesis"
            href="#genesis"
            onClick={(e) => {
              e.preventDefault();
              onNavigate(ScreenId.Génesis);
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-300 md:flex items-center gap-1.5 ${
              currentScreen === ScreenId.Génesis
                ? "bg-forest-800 border border-bionic-green/30 text-bionic-green"
                : "text-forest-100 hover:text-bionic-green hover:bg-forest-900/60"
            }`}
          >
            <Compass className="w-3.5 h-3.5 hidden md:inline" />
            Inicio
          </a>

          <a
            id="nav-link-metabolismo"
            href="#investigacion"
            onClick={(e) => {
              e.preventDefault();
              onNavigate(ScreenId.Metabolismo);
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-300 md:flex items-center gap-1.5 ${
              currentScreen === ScreenId.Metabolismo
                ? "bg-forest-800 border border-bionic-green/30 text-bionic-green"
                : "text-forest-100 hover:text-bionic-green hover:bg-forest-900/60"
            }`}
          >
            <Cpu className="w-3.5 h-3.5 hidden md:inline" />
            Investigación
          </a>

          <a
            id="nav-link-senda"
            href="#galeria"
            onClick={(e) => {
              e.preventDefault();
              onNavigate(ScreenId.Senda);
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-300 md:flex items-center gap-1.5 ${
              currentScreen === ScreenId.Senda
                ? "bg-forest-800 border border-bionic-green/30 text-bionic-green"
                : "text-forest-100 hover:text-bionic-green hover:bg-forest-900/60"
            }`}
          >
            <Landmark className="w-3.5 h-3.5 hidden md:inline" />
            Galería
          </a>

          <a
            id="nav-link-cultura"
            href="#cultura"
            onClick={(e) => {
              e.preventDefault();
              onNavigate(ScreenId.TejidoHumano);
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-300 md:flex items-center gap-1.5 ${
              currentScreen === ScreenId.TejidoHumano
                ? "bg-forest-800 border border-bionic-green/30 text-bionic-green"
                : "text-forest-100 hover:text-bionic-green hover:bg-forest-900/60"
            }`}
          >
            <Users className="w-3.5 h-3.5 hidden md:inline" />
            Cultura
          </a>
        </div>
      </div>
    </nav>
  );
}
