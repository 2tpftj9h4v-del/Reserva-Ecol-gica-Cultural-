import React, { useState, useRef } from "react";
import { ScreenId, Myth } from "../types";
import { ArrowRight, Compass, Eye, ShieldCheck, Moon, Sparkles, MapPin } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface InicioGenesisProps {
  onNavigate: (screen: ScreenId) => void;
}

const MYTHICAL_LEGENDS: Myth[] = [
  {
    id: "myth-1",
    title: "El Guardián del Agua Lúmina",
    guardian: "Ngen-ko",
    description: "Espíritu protector de las vertientes de la cascada. Se dice que el agua de la reserva brilla de noche porque circula a través de las raíces de helechos bioluminiscentes antiguos bajo su custodia.",
    coordinates: "S 39° 52' 41\" O 72° 08' 11\"",
    wisdom: "El agua líquida es la memoria de la montaña alta dictando el destino biológico de los valles.",
    color: "from-blue-500/20 via-cyan-500/10 to-transparent",
  },
  {
    id: "myth-2",
    title: "La Madre Sabia del Micelio",
    guardian: "Fücha-Kuyen",
    description: "La tejedora de la red invisible. Mitos comunales describen impulsos de luz viajando entre los árboles a través del sustrato fúngico cuando el bosque entra en su letargo invernal.",
    coordinates: "S 39° 52' 55\" O 72° 08' 24\"",
    wisdom: "Ningún árbol crece solo. La fuerza verdadera reside en el flujo químico de la reciprocidad oculta.",
    color: "from-emerald-500/20 via-teal-500/10 to-transparent",
  },
  {
    id: "myth-3",
    title: "La Abuela de la Sabiduría Austral",
    guardian: "Pillán-Alwe",
    description: "La gran Araucaria ancestral que sobrevivió tres erupciones volcánicas corporizando el concepto de 'Génesis'. Sus anillos guardan el registro histórico climatológico de los últimos 800 años.",
    coordinates: "S 39° 53' 01\" O 72° 07' 59\"",
    wisdom: "La resiliencia de la madera es el tiempo endurecido listo para sostener el peso de las futuras comunas.",
    color: "from-amber-500/20 via-orange-500/10 to-transparent",
  }
];

export default function InicioGenesis({ onNavigate }: InicioGenesisProps) {
  const [selectedMyth, setSelectedMyth] = useState<Myth | null>(null);
  const oracleSectionRef = useRef<HTMLDivElement>(null);

  const scrollToOracle = () => {
    oracleSectionRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div id="screen-genesis" className="min-h-screen text-forest-50 select-none pb-20">
      {/* Hero Section */}
      <div 
        id="genesis-hero"
        className="relative h-[90vh] md:h-[95vh] flex items-center justify-center overflow-hidden"
      >
        {/* Background Image with elegant overlay overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            id="genesis-bg-img"
            src="https://lh3.googleusercontent.com/aida/AP1WRLvrLmLJxAZwV02CC_0EELCLQd5f74p28zev8HlxU1prlDExot1v6xD5pELMnsq8tqm_XQYTly4jspab6PhHilKSXWB8EVynLBkrhVzNjSpbTYz3EGC32ar3fSs3flyEI1X2blXAEJqmXkrzPQ5X5FYYTfJF-cFLw8Djg4zVbefFGUGnlqjXJX_WAMChkNkJYBGOdBvkmPxeP0ad4QwePPpw12BXlRTEIaGLcybIxuyl3GQB0ZmBbUgPeXM"
            alt="Reserva Ecológica Cultural"
            className="w-full h-full object-cover scale-105 motion-safe:animate-[pulse_10s_ease-in-out_infinite]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-moss-950 via-moss-950/70 to-moss-950/30" />
          <div className="absolute inset-0 bg-gradient-to-r from-moss-950/80 via-transparent to-moss-950/20" />
        </div>

        {/* Hero Core Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            {/* Top Indicator */}
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-forest-900/80 border border-bionic-green/30 rounded-full text-[11px] font-mono tracking-widest text-bionic-green uppercase mb-8">
              <Sparkles className="w-3 h-3 text-bionic-green animate-spin" />
              Santuario de Regeneración y Memoria
            </div>

            {/* Main Title */}
            <h1 
              id="genesis-heading"
              className="text-4xl md:text-7xl font-serif font-bold tracking-tight text-white mb-6 uppercase"
            >
              Génesis <span className="text-bionic-light block md:inline font-sans text-xl md:text-4xl font-light tracking-widest block mt-2 md:mt-0 md:-ml-2">| RESERVA ECOLÓGICA CULTURAL</span>
            </h1>

            {/* Subtitle */}
            <p className="text-md md:text-xl text-forest-100 font-sans font-light max-w-3xl mx-auto leading-relaxed mb-10">
              Un santuario donde la sabiduría ancestral se entrelaza con el flujo metabólico de la tierra. Un puente vivo de arquitectura orgánica y diseño comunitario.
            </p>

            {/* Call to Actions buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                id="btn-explorar-reserva"
                onClick={scrollToOracle}
                className="w-full sm:w-auto px-8 py-4 bg-forest-800 hover:bg-forest-600 text-bionic-green hover:text-white border border-bionic-green/40 hover:border-bionic-green rounded-full font-semibold text-xs tracking-wider transition-all duration-300 shadow-lg flex items-center justify-center gap-2 cursor-pointer uppercase"
              >
                <Compass className="w-4 h-4" />
                Explorar Reserva
              </button>

              <button
                id="btn-ver-protocolos"
                onClick={() => onNavigate(ScreenId.Metabolismo)}
                className="w-full sm:w-auto px-8 py-4 bg-bionic-green hover:bg-bionic-light text-moss-950 hover:scale-[1.02] rounded-full font-bold text-xs tracking-wider transition-all duration-300 shadow-xl flex items-center justify-center gap-2 cursor-pointer uppercase"
              >
                <ShieldCheck className="w-4 h-4 text-moss-950" />
                Ver Protocolos
              </button>

              <button
                id="btn-ver-mitologia"
                onClick={scrollToOracle}
                className="w-full sm:w-auto px-8 py-4 bg-transparent hover:bg-forest-900/40 text-forest-50 border border-forest-600/60 hover:border-forest-200 rounded-full font-semibold text-xs tracking-wider transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer uppercase"
              >
                <Moon className="w-4 h-4 text-bionic-amber" />
                Ver Mitología
              </button>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 opacity-60">
          <span className="text-[10px] font-mono tracking-widest text-forest-200 uppercase">
            Sumergirse en Génesis
          </span>
          <div className="w-1.5 h-6 bg-forest-800 rounded-full relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1/2 bg-bionic-green rounded-full animate-[bounce_1.5s_infinite]" />
          </div>
        </div>
      </div>

      {/* Overview Block with Anillos de Vida cascading water circular graphic */}
      <div className="max-w-6xl mx-auto px-6 mt-16 md:mt-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Dynamic Graphic and Info */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative group">
              <div className="absolute -inset-2 rounded-full bg-gradient-to-tr from-bionic-green to-bionic-amber opacity-30 blur-xl group-hover:opacity-40 transition-all duration-500" />
              <div className="relative backdrop-blur-md bg-moss-950 border border-forest-800 p-4 rounded-full overflow-hidden w-72 h-72 md:w-96 md:h-96 flex items-center justify-center shadow-2xl">
                <img 
                  id="cascada-anillo-img"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCh4H76B3YNAUM2b6mRuRJVDJfCy9ZQAXnfEnz5FBP247F-RhCUAe_YJj46ISZzB_--_6i68D_NSmY76Yvoa6RmxfSezDaNsxxvflEDTCkYdb5TJ7gM2yFySaMa4XvwrRm-N1q8wpaCuK1-TEGCbEptOHNzgTNl0VDW7K9kdcWiaZt6Gk9VeuEJe7Dg7t_fhw3o11lc1bB4p9r2MWEC23ORGYI5HHPQfPXTvoMMq_d4cT0jOHOhTvtGNJISYY57HC7coODb2PtdT8E"
                  alt="Anillos de Vida - Cascada"
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                />
                
                {/* Bioluminescent micro floating tags inside the circle for high fidelity */}
                <span className="absolute top-[20%] left-[10%] bg-moss-950/90 border border-bionic-green/40 px-2 py-0.5 rounded text-[9px] font-mono tracking-wider text-bionic-green uppercase shadow">
                  Cascan-ko 92%
                </span>
                <span className="absolute bottom-[25%] right-[5%] bg-moss-950/90 border border-bionic-amber/40 px-2 py-0.5 rounded text-[9px] font-mono tracking-wider text-bionic-amber uppercase shadow">
                  Flujo de Vida
                </span>
              </div>
            </div>
          </div>

          {/* Description of Anillos de Vida */}
          <div className="lg:col-span-7 space-y-6">
            <div className="font-mono text-xs text-bionic-green tracking-widest uppercase">
              // Dinámica Sostenible
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-black tracking-tight text-white uppercase">
              Anillos de Vida: El Ciclo de las Cascadas Claras
            </h2>
            <p className="text-forest-100 font-sans font-light leading-relaxed">
              La cascada de la reserva no es meramente un accidente geográfico; constituye la arteria hídrica principal de la comuna y el metabólico forestal. A través de un sofisticado sensor dinámico, medimos la oxigenación, sedimentación silícea y temperatura en tiempo real. 
            </p>
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="p-4 bg-forest-900/60 rounded-2xl border border-forest-800/40">
                <span className="block text-xl font-mono text-bionic-green font-bold">1,820 L/s</span>
                <span className="block text-xs text-forest-200 mt-1">Caudal Promedio Neto</span>
              </div>
              <div className="p-4 bg-forest-900/60 rounded-2xl border border-forest-800/40">
                <span className="block text-xl font-mono text-bionic-amber font-bold">98.4%</span>
                <span className="block text-xs text-forest-200 mt-1">Nivel de Pureza Biológica</span>
              </div>
            </div>
            <div className="pt-2">
              <button
                id="btn-ver-detalles-cascada"
                onClick={() => onNavigate(ScreenId.Metabolismo)}
                className="inline-flex items-center gap-2 group text-xs text-bionic-green hover:text-bionic-light font-bold tracking-wider uppercase transition-all duration-300"
              >
                Analizar telemetría de cascada
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </div>
          
        </div>
      </div>

      {/* Mythology Oracle section (Target of VER MITOLOGÍA) */}
      <div 
        id="mythology-oracle-section" 
        ref={oracleSectionRef}
        className="max-w-6xl mx-auto px-6 mt-28 pt-10"
      >
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="font-mono text-xs text-bionic-green tracking-widest uppercase mb-2">
            // Cosmología y Memoria Ancestral
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold uppercase text-white">
            El Oráculo Mitológico del Territorio
          </h2>
          <p className="text-forest-100 font-sans font-light text-sm mt-2">
            Selecciona un espíritu protector para invocar la sabiduría resguardada en los ciclos invisibles de la Reserva.
          </p>
        </div>

        {/* Legend grid picker */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {MYTHICAL_LEGENDS.map((legend) => (
            <button
              id={`myth-picker-${legend.id}`}
              key={legend.id}
              onClick={() => setSelectedMyth(legend)}
              className={`p-6 bg-gradient-to-b ${legend.color} border rounded-3xl text-left transition-all duration-300 hover:border-bionic-green relative overflow-hidden group cursor-pointer focus:outline-none flex flex-col justify-between h-64 ${
                selectedMyth?.id === legend.id ? "border-bionic-green ring-2 ring-bionic-green/20" : "border-forest-800"
              }`}
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-bionic-green/5 rounded-full blur-2xl group-hover:bg-bionic-green/10 transition-all" />
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-mono tracking-widest text-bionic-green uppercase">
                    Guardián: {legend.guardian}
                  </span>
                  <div className="p-1 px-1.5 border border-bionic-green/20 rounded text-[9px] font-mono text-forest-200 uppercase bg-moss-950">
                    Santuario Estelar
                  </div>
                </div>
                <h3 className="text-lg font-serif font-bold text-white mb-2 group-hover:text-bionic-green transition-colors">
                  {legend.title}
                </h3>
                <p className="text-xs text-forest-100 font-sans line-clamp-3 leading-relaxed">
                  {legend.description}
                </p>
              </div>
              <div className="flex items-center gap-1.5 text-[9px] font-mono text-bionic-green/80 mt-4">
                <MapPin className="w-3 h-3 text-bionic-amber" />
                {legend.coordinates}
              </div>
            </button>
          ))}
        </div>

        {/* Myth details display */}
        <AnimatePresence mode="wait">
          {selectedMyth && (
            <motion.div
              id="selected-myth-details"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mt-8 p-8 backdrop-blur-md bg-forest-900/60 border border-bionic-green-400 rounded-3xl relative overflow-hidden"
            >
              <div className="absolute -top-12 -right-12 w-48 h-48 bg-bionic-green/10 rounded-full blur-3xl" />
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                <div className="md:col-span-8">
                  <span className="text-xs font-mono text-bionic-amber font-semibold block uppercase tracking-wider mb-2">
                    // Sabiduría Ancestral Activa (Oráculo)
                  </span>
                  <h4 className="text-2xl font-serif font-black text-white uppercase mb-4">
                    {selectedMyth.title} — El Legado de {selectedMyth.guardian}
                  </h4>
                  <p className="text-forest-100 font-sans font-light text-sm leading-relaxed mb-4">
                    {selectedMyth.description} Itinerarios ancestrales sugieren que este espíritu ejerce gobernanza sobre la resiliencia microgástral y los canales de biomasa de la cuenca.
                  </p>
                  <blockquote className="border-l-2 border-bionic-amber pl-4 italic text-sm text-bionic-amber/90 font-serif my-3">
                    "{selectedMyth.wisdom}"
                  </blockquote>
                </div>
                <div className="md:col-span-4 flex flex-col items-center justify-center p-6 bg-moss-950/80 border border-forest-800 rounded-2xl">
                  <span className="text-[10px] font-mono text-forest-200 uppercase tracking-widest block mb-1">
                    Coordenadas de Poder
                  </span>
                  <span className="text-xs font-mono text-white font-semibold">
                    {selectedMyth.coordinates}
                  </span>
                  <button
                    id="btn-ir-senda-mitologica"
                    onClick={() => onNavigate(ScreenId.Senda)}
                    className="mt-4 px-4 py-2 bg-forest-800 border border-forest-600/60 hover:border-bionic-green rounded-full text-[10px] font-mono tracking-widest text-bionic-green hover:text-white transition-all w-full text-center cursor-pointer uppercase"
                  >
                    Estudiar Senda de Templos
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
