import React, { useState, useRef } from "react";
import { CommuneProfile } from "../types";
import { Users, Sun, Vote, Utensils, Compass, ArrowRight, ShieldCheck, Heart, Sparkles, MessageCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const SIMULATED_PROFILES: CommuneProfile[] = [
  {
    id: "prof-1",
    role: "Cocinera Solar Colectiva",
    character: "Clara Pallacan",
    quote: "Aprovechamos la radiación parabólica concentrada para alimentar sanamente a 45 familias sin recurrir a talar leña.",
    accentColor: "border-bionic-amber text-bionic-amber text-amber-300 bg-amber-500/10",
    schedule: [
      { time: "08:30 AM", activity: "Calibración térmica de espejos parabólicos", impact: "Alineación inicial al espectro lumínico de la colina norte" },
      { time: "11:00 AM", activity: "Cocción lenta de legumbres comunales", impact: "Cero gases combustionados. Rendimiento térmico de 180°C" },
      { time: "01:30 PM", activity: "Almuerzo colectivo bajo los aleros geodésicos", impact: "Consumo solidario de cultivos hidropónicos" }
    ]
  },
  {
    id: "prof-2",
    role: "Artesano de Materiales",
    character: "Lautaro Huaiquimilla",
    quote: "La rigidez estructural no se domina con clavos de fierro, sino hilando fibras de mimbre y cargando greda arcillosa.",
    accentColor: "border-emerald-300 text-emerald-300 text-emerald-300 bg-emerald-500/10",
    schedule: [
      { time: "07:00 AM", activity: "Recolección selectiva de mimbre flexible", impact: "Poda conservacionista en los cauces fluviales" },
      { time: "09:30 AM", activity: "Inoculación micelial en moldes estructurales", impact: "Cultivo y solidificación natural de paredes" },
      { time: "03:00 PM", activity: "Tejido de vigas cruzadas de alta curvatura", impact: "Estructuras capaces de resistir sismos por flexibilidad" }
    ]
  },
  {
    id: "prof-3",
    role: "Mediador de Holocracia",
    character: "Elena Soler",
    quote: "La voz de un niño pesa tanto como la del anciano silvicultor. Buscamos el consentimiento profundo, no mayorías forzadas.",
    accentColor: "border-blue-400 text-blue-400 text-blue-300 bg-blue-500/10",
    schedule: [
      { time: "10:00 AM", activity: "Revisión de propuestas en el foro abierto", impact: "Ordenamiento del debate con software ético local" },
      { time: "04:30 PM", activity: "Círculo de consenso en el Pabellón del Origen", impact: "Resolución holocrática de proyectos comunitarios" },
      { time: "07:00 PM", activity: "Sincronización de bitácoras biocibernéticas", impact: "Integración de métricas forestales en la agenda social" }
    ]
  }
];

interface Proposal {
  id: string;
  title: string;
  description: string;
  votesYes: number;
  votesNo: number;
  category: "Energía" | "Infraestructura" | "Soberanía";
}

export default function CulturaTejidoHumano() {
  const [selectedProfile, setSelectedProfile] = useState<CommuneProfile>(SIMULATED_PROFILES[0]);
  const [proposals, setProposals] = useState<Proposal[]>([
    {
      id: "prop-1",
      title: "Optimizar Biogás comunal mediante excedentes de cultivo",
      description: "Adicionar un biodigestor secundario en los canteros de micelio para precalentar las ollas de la Cocina Solar en días nublados.",
      votesYes: 42,
      votesNo: 3,
      category: "Energía"
    },
    {
      id: "prop-2",
      title: "Erigir el Pabellón Infantil de la Sabiduría Húmeda",
      description: "Construir una pequeña cúpula de mimbre y totora al borde del canal hídrico para la enseñanza silvicultural de las infancias comunales.",
      votesYes: 31,
      votesNo: 1,
      category: "Infraestructura"
    }
  ]);
  const [userVoted, setUserVoted] = useState<string[]>([]);

  const timelineRef = useRef<HTMLDivElement>(null);
  const voteRef = useRef<HTMLDivElement>(null);

  const handleVote = (proposalId: string, type: "yes" | "no") => {
    if (userVoted.includes(proposalId)) return;
    setProposals(
      proposals.map((p) => {
        if (p.id === proposalId) {
          return {
            ...p,
            votesYes: type === "yes" ? p.votesYes + 1 : p.votesYes,
            votesNo: type === "no" ? p.votesNo + 1 : p.votesNo
          };
        }
        return p;
      })
    );
    setUserVoted([...userVoted, proposalId]);
  };

  const scrollToSection = (ref: React.RefObject<HTMLDivElement | null>) => {
    ref.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div id="screen-tejidohumano" className="min-h-screen text-forest-50 select-none pb-24">
      {/* Community Hero Accent */}
      <div className="relative h-[65vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            id="tejidohumano-hero-img"
            src="https://lh3.googleusercontent.com/aida/AP1WRLvSms7xjiljRqI4xxcYxhCBIKClrxXqRMIEvxq-ORIFHUWBOuh4u4Y8FRIEGzfkkUMiyh8U_O1cYdfPYqoYErfN5szivKVvNAxELisZoO73hNqW-iODABa9krWWb2Rq7_XE7KEaYNdOje9Q9ffpIYG8U6pmMjSOwXTwDs-BUyKjVhJ6h4YzgAIhTOO_WnR_W8ZQK03Lcj6WgoAxlUMbfmxXJ_b2jBD53ETMuXylV5lEtxhAuwtvtNa_JHU"
            alt="Comunidad Tejido Humano"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-moss-950 via-moss-950/80 to-moss-950/40" />
        </div>

        {/* Hero Core Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-moss-950 border border-bionic-green/30 rounded-full text-[10px] font-mono tracking-widest text-[#34d399] uppercase mb-6 shadow-xl">
            <Users className="w-3.5 h-3.5" />
            Vivir en Común acuerdo filosófico
          </div>
          <h1 
            id="tejidohumano-heading"
            className="text-4xl md:text-6xl font-serif font-black tracking-tight text-white mb-4 uppercase"
          >
            Tejido Humano
          </h1>
          <p className="text-forest-100 font-sans font-light text-sm md:text-lg max-w-2xl mx-auto leading-relaxed mb-8">
            Establecemos un modelo comunitario autosuficiente donde la autogestión, la cocina solar limpia y la democracia directa resguardan el equilibrio de la Reserva del Corazón.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              id="btn-trigger-vivir-comuna"
              onClick={() => scrollToSection(timelineRef)}
              className="px-6 py-3.5 bg-bionic-green hover:bg-bionic-light text-moss-950 font-bold rounded-full text-xs tracking-wider transition-all flex items-center gap-2 cursor-pointer uppercase shadow-lg"
            >
              <Compass className="w-4 h-4 text-moss-950" />
              Vivir la Comuna
            </button>
            <button
              id="btn-trigger-democracia"
              onClick={() => scrollToSection(voteRef)}
              className="px-6 py-3.5 bg-forest-800 hover:bg-forest-600 border border-bionic-green/40 hover:border-bionic-green rounded-full font-semibold text-xs tracking-wider text-bionic-green hover:text-white transition-all flex items-center gap-2 cursor-pointer uppercase"
            >
              <Vote className="w-4 h-4 text-bionic-green" />
              Votar Propuestas
            </button>
          </div>
        </div>
      </div>

      {/* Main Core Showcase blocks */}
      <div className="max-w-6xl mx-auto px-6 mt-16 space-y-20">
        
        {/* Block A: Cocina Solar Comunal */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="p-2 border border-forest-800 rounded-[32px] overflow-hidden bg-moss-950 shadow-2xl relative group">
              <img 
                id="cultura-solar-img"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBF6x_ePIwmFx6RzWeWHpJOIoLvdeIxxt6q67HBKbqOsrdcD3eYOSHFPc2dafsVjjZNsWJH14R3wy44wiFTfsLHta2VqCnWC82WbwGtbuSRsxX4mqpJVXqULnMkYYTH2FwcRGwWXe5rtIt0NZWZItcbG_xSzGNpbBtHFvTjxDj1B1F3oHYuoysw65oSjsgG8XJWJB7uqDACSlDiWsRhS8RDMLZ3qOZNan8DiugHZWvh93trKG1jY41saVfB3YrKMxEvT_zRz5v0oac" 
                alt="Cocina Solar Comunal" 
                className="w-full h-80 object-cover rounded-[24px] group-hover:scale-102 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-6 left-6 bg-moss-950/95 border border-bionic-amber/40 px-3 py-1 rounded text-[9px] font-mono tracking-widest text-[#fbbf24] uppercase">
                Módulo Parabólico Activo
              </span>
            </div>
          </div>
          <div className="lg:col-span-7 space-y-4 text-left">
            <div className="flex items-center gap-2 text-bionic-amber font-mono text-xs uppercase tracking-widest">
              <Sun className="w-4 h-4 text-bionic-amber" />
              // Energía Solares Parabólicas
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-black text-white uppercase leading-none">
              La Cocina Solar Comunal
            </h2>
            <p className="text-forest-100 font-sans text-xs md:text-sm font-light leading-relaxed">
              La subsistencia de la comuna no genera humo. Equipados con concentradores parabólicos reflectantes que siguen mecánicamente el eje terrestre, procesamos alimentos comunitarios diarios a temperaturas de horneado completas. Un circuito de soberanía hídrica reutiliza el vapor destilado, condensándolo para regar los canteros comestibles de frambuesas y hortalizas nativas.
            </p>
            <div className="p-4 bg-forest-900/30 border border-forest-800/40 rounded-2xl grid grid-cols-3 gap-2 text-center">
              <div>
                <span className="block text-md font-mono text-bionic-amber font-bold">180°C</span>
                <span className="block text-[8px] text-forest-200 uppercase mt-0.5">Temp Promedio</span>
              </div>
              <div className="w-px bg-forest-800 self-center h-8 mx-auto" />
              <div>
                <span className="block text-md font-mono text-bionic-green font-bold">0%</span>
                <span className="block text-[8px] text-forest-200 uppercase mt-0.5">Emisión CO₂</span>
              </div>
            </div>
          </div>
        </div>

        {/* Block B: Holocracia Fluida */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center lg:flex-row-reverse">
          <div className="lg:col-span-12 lg:hidden">
            {/* Small screen placeholder node matching order layout */}
          </div>
          <div className="lg:col-span-7 space-y-4 text-left">
            <div className="flex items-center gap-2 text-bionic-green font-mono text-xs uppercase tracking-widest">
              <Vote className="w-4 h-4 text-bionic-green" />
              // Democracia de Consenso Crítico
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-black text-white uppercase leading-none">
              Holocracia Fluida
            </h2>
            <p className="text-forest-100 font-sans text-xs md:text-sm font-light leading-relaxed">
              En lugar de jerarquías piramidales, nos organizamos en círculos interconectados que interactúan dinámicamente. Cada propuesta se debate buscando el consentimiento absoluto: el proyecto se aprueba solo si ningún miembro expresa una objeción razonada basada en el bienestar ecológico profundo de la Reserva. Un software interno de código abierto registra y despliega los flujos de consenso.
            </p>
            <button
              id="btn-ver-asamblea"
              onClick={() => scrollToSection(voteRef)}
              className="inline-flex items-center gap-2 group text-xs text-bionic-green hover:text-bionic-light font-bold tracking-wider uppercase transition-all duration-300"
            >
              Explorar foro de deliberaciones
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="p-2 border border-forest-800 rounded-[32px] overflow-hidden bg-moss-950 shadow-2xl relative group">
              <img 
                id="gubernatura-holocracia-img"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuA8HMtJ85LR_XLGm9SJIH3Npx6nh0pSOCgWhSG8XuhHV6F0mWoeoZ7Kw3S2v1gguyrF2Qw_iuK7X5Lmq0mCk_bJY9mNofcKoAeRP8bFj1Ab3aSl65NCmhCWOLMyZMXgj4KPveTAPIDOuX8DDwUbX5SZpYDjXNceUk7Kpf1iJ4f0NmDk6-DeGq3_uoxT3sB-9SaUqjZUReVeeK66773dR0zBZ_GXy6lmel5eWkrPkrpMYvddLVXjHRCW8U_UOlP4dFlLKhF5Bs_np8k" 
                alt="Holocracia Fluida" 
                className="w-full h-80 object-cover rounded-[24px] group-hover:scale-102 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-6 left-6 bg-moss-950/95 border border-bionic-green/40 px-3 py-1 rounded text-[9px] font-mono tracking-widest text-[#34d399] uppercase">
                Asamblea Democrática Abierta
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* SECTION: VIVIR LA COMUNA (Commune daily roles interactive timeline scheduler) */}
      <div 
        id="comuna-timeline-section"
        ref={timelineRef}
        className="max-w-6xl mx-auto px-6 border-t border-forest-800/50 pt-16 mb-20 mt-16"
      >
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[10px] font-mono text-bionic-green uppercase tracking-widest block mb-1">
            // Simulador de Coexistencia Diaria
          </span>
          <h2 className="text-3xl font-serif font-bold text-white uppercase">
            Vivir la Comuna (Bitácoras Colectivas)
          </h2>
          <p className="text-xs text-forest-100 font-sans mt-2">
            Elige uno de los perfiles comunales y explora su agenda horaria para conocer cómo coordina sus tareas diarias con el metabolismo biótico de la Reserva.
          </p>
        </div>

        {/* Profile pickers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 bg-moss-950 p-2.5 border border-forest-800 rounded-3xl">
          {SIMULATED_PROFILES.map((prof) => (
            <button
              id={`profile-picker-${prof.id}`}
              key={prof.id}
              onClick={() => setSelectedProfile(prof)}
              className={`p-4 rounded-2xl text-left border transition-all cursor-pointer ${
                selectedProfile.id === prof.id
                  ? "bg-forest-800 border-bionic-green text-white shadow-xl"
                  : "bg-transparent border-transparent text-forest-100 hover:bg-forest-900/40"
              }`}
            >
              <span className="block text-[10px] font-mono text-bionic-green tracking-widest uppercase mb-1">// Rol Comunal</span>
              <span className="block text-md font-serif font-black uppercase text-white truncate">{prof.role}</span>
              <span className="block text-xs font-sans text-forest-200 mt-0.5">{prof.character}</span>
            </button>
          ))}
        </div>

        {/* Selected profile interactive schedule timeline layout */}
        <div className="bg-forest-900/10 border border-forest-800 p-6 md:p-8 rounded-3xl relative overflow-hidden">
          <div className="absolute top-4 right-4 bg-moss-950 border border-forest-800 px-3 py-1.5 rounded-full text-[10px] font-mono text-bionic-amber flex items-center gap-1.5 shadow-md">
            <Heart className="w-3.5 h-3.5 fill-bionic-amber text-bionic-amber" />
            Agenda Activa Consensuada
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Description side */}
            <div className="lg:col-span-4 space-y-4">
              <span className="inline-block px-3 py-1 bg-bionic-green/10 border border-bionic-green/20 rounded-full text-[10px] font-mono text-bionic-green uppercase tracking-wider">
                Residente de la Reserva
              </span>
              <h3 className="text-xl font-serif font-black text-white uppercase">{selectedProfile.role}</h3>
              <p className="text-xs text-forest-100 font-sans italic leading-relaxed">
                "{selectedProfile.quote}"
              </p>
              <div className="pt-2">
                <span className="block text-[8px] font-mono text-forest-200">FIRMA COLECTIVA</span>
                <span className="text-xs font-mono text-white tracking-widest block font-bold">{selectedProfile.character.toUpperCase()}</span>
              </div>
            </div>

            {/* Timeline cards side */}
            <div className="lg:col-span-8 space-y-4">
              <span className="text-[10px] font-mono text-forest-200 uppercase tracking-widest block mb-2">Cronograma de Contribuciones Diarias</span>
              <div className="relative border-l border-forest-800 ml-3.5 pl-6 space-y-6">
                {selectedProfile.schedule.map((item, index) => (
                  <div key={index} className="relative group text-left">
                    {/* Node point circular dot icon */}
                    <div className="absolute -left-[30px] top-0.5 bg-moss-950 border-2 border-bionic-green rounded-full w-4.5 h-4.5 group-hover:bg-bionic-green transition-all" />
                    
                    <div className="p-4 bg-moss-950/80 border border-forest-850 hover:border-forest-700/80 rounded-2xl transition-all">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1.5">
                        <span className="text-xs font-mono text-bionic-green font-bold tracking-tight">{item.time}</span>
                        <span className="text-[9px] font-mono font-medium text-forest-200 uppercase mt-1 sm:mt-0">Soberanía de Recursos</span>
                      </div>
                      <h4 className="text-xs font-bold text-white uppercase">{item.activity}</h4>
                      <p className="text-[11px] text-forest-100 font-sans mt-1">
                        Impacto colectivo: {item.impact}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* SECTION: HOLOCRACIA VOTING (Active community Proposals circular consensus) */}
      <div 
        id="voting-consensus-section"
        ref={voteRef}
        className="max-w-6xl mx-auto px-6 border-t border-forest-800/50 pt-16"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Deliberative information side */}
          <div className="lg:col-span-5 space-y-4 text-left">
            <span className="text-[10px] font-mono text-bionic-green uppercase tracking-widest block mb-1">
              // Plataforma Autogestionaria Corazón-Decide
            </span>
            <h2 className="text-3xl font-serif font-black text-white uppercase leading-none">
              Consenso Activo de la Asamblea
            </h2>
            <p className="text-xs text-forest-100 font-sans mt-3 leading-relaxed">
              La asamblea de holocracia evalúa propuestas con un sistema de deliberación directa. Como visitante o miembro asociado de la Comuna de la Reserva, puedes participar emitiendo un voto consultivo para calibrar el grado de aceptación comunitaria.
            </p>
            <div className="flex items-center gap-2 p-3.5 bg-yellow-950/20 border border-bionic-amber/30 text-bionic-amber rounded-2xl text-[10px] font-mono leading-tight">
              <MessageCircle className="w-5 h-5 text-bionic-amber shrink-0" />
              <span>Para aprobarse definitivamente, el proyecto requiere consentimiento unánime sin objeciones fundamentales de seguridad comunitaria.</span>
            </div>
          </div>

          {/* Proposals voting cards list */}
          <div className="lg:col-span-7 space-y-4">
            <span className="text-[10px] font-mono text-forest-200 uppercase tracking-widest block md:mb-2">Propuestas Pendientes de Consenso</span>
            
            <div className="space-y-4">
              {proposals.map((prop) => {
                const totalVotes = prop.votesYes + prop.votesNo;
                const yesPercentage = totalVotes > 0 ? Math.round((prop.votesYes / totalVotes) * 100) : 0;
                const voted = userVoted.includes(prop.id);

                return (
                  <div key={prop.id} className="p-5 bg-moss-950 border border-forest-800 rounded-3xl relative overflow-hidden text-left">
                    <div className="flex justify-between items-center mb-4">
                      <span className="px-2 py-0.5 bg-forest-900 border border-forest-800 rounded text-[9px] font-mono text-forest-100 uppercase">
                        Categoría: {prop.category}
                      </span>
                      <span className="text-[9px] font-mono text-forest-200">ID PROPOSAL: PROP_P{prop.id.slice(-1)}</span>
                    </div>

                    <h3 className="text-sm font-bold text-white uppercase mb-1.5">{prop.title}</h3>
                    <p className="text-xs text-forest-100 font-sans leading-relaxed mb-4">{prop.description}</p>

                    {/* Progress bar and statistics of votes */}
                    <div className="bg-forest-900/40 p-3 rounded-xl border border-forest-850/40 text-xs mb-4">
                      <div className="flex justify-between items-center font-mono text-[9px] text-forest-200 mb-1.5">
                        <span>Aceptación Comunitaria</span>
                        <span>{yesPercentage}% Sí ({prop.votesYes} de {totalVotes} votos)</span>
                      </div>
                      <div className="w-full bg-forest-950 h-2 rounded-full overflow-hidden border border-forest-850">
                        <div className="bg-bionic-green h-full" style={{ width: `${yesPercentage}%` }} />
                      </div>
                    </div>

                    {/* Voting buttons */}
                    <div className="flex items-center gap-3">
                      <button
                        id={`vote-yes-${prop.id}`}
                        onClick={() => handleVote(prop.id, "yes")}
                        disabled={voted}
                        className={`px-4 py-2 text-[10px] font-mono tracking-wider rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
                          voted 
                            ? "bg-transparent border border-forest-800 text-forest-100 disabled:opacity-75" 
                            : "bg-emerald-950 hover:bg-emerald-900 text-bionic-green border border-bionic-green/40 hover:border-bionic-green"
                        }`}
                      >
                        Consentir (Sí)
                      </button>
                      <button
                        id={`vote-no-${prop.id}`}
                        onClick={() => handleVote(prop.id, "no")}
                        disabled={voted}
                        className={`px-4 py-2 text-[10px] font-mono tracking-wider rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
                          voted 
                            ? "bg-transparent border border-forest-850 text-forest-100 disabled:opacity-75" 
                            : "bg-transparent border border-forest-750 hover:border-red-500 hover:text-red-400 text-forest-100"
                        }`}
                      >
                        Elevar Objeción (No)
                      </button>
                      {voted && (
                        <span className="text-[9px] font-mono text-bionic-green ml-auto animate-pulse">
                          ✓ Voto consultivo registrado
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
