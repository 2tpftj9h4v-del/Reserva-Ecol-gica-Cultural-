import React, { useState, useRef } from "react";
import { Pavilion } from "../types";
import { Landmark, Compass, Sliders, CheckSquare, Sparkles, FolderOpen, Download, AlertCircle, RefreshCw, Star } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const PAVILIONS_DATA: Pavilion[] = [
  {
    id: "pavilion-1",
    name: "Pabellón del Origen",
    volume: "1,240 m³",
    height: "14.5 m",
    materials: [
      { name: "Madera de Alerce Local", source: "Silvicultura Regulada", ratio: 60 },
      { name: "Bio-cemento de Tierra", source: "Greda Arcillosa", ratio: 25 },
      { name: "Tejido de Totora", source: "Humeda Cuenca", ratio: 15 }
    ],
    carbonOffset: "-42.8 Ton CO₂",
    description: "Ubicado en la entrada de la Senda. Su estructura cónica asimétrica rinde homenaje a los refugios mapuches prehispánicos. Las aberturas cenitales permiten el ingreso oblicuo de la luz estelar durante los equinoccios climáticos.",
    blueprintImage: "https://lh3.googleusercontent.com/aida-public/AB6AXuCZNVhWYWIE1NJEW3593rp-J5lOK7FR3I2GrAxfc6GqrSmwmtFIq_Oqz9nJnPw63lD5ggwOXQ6bGUoWIMtHpMJT7mnl_hBQBGuBBbNPbGgsn69wo7Hnsrqxy1dRldACknh9O1anpV6DTtJNkVEEnALuJ21TcAxyclGZlIWR7Wja946wj3Jo8kS4_wVICmMzMeevtUmrW_qKlq-A3Zz2KHs2bodYcWFM6H5MubJ7Kw_HFvEpCznHxWXsm7ic3_HfDxzMoLO04p-qysU"
  },
  {
    id: "pavilion-2",
    name: "El Anillo Hídrico",
    volume: "820 m³",
    height: "6.2 m",
    materials: [
      { name: "Mimbre Estructurado", source: "Mimbreras de Chimbarongo", ratio: 50 },
      { name: "Piedra Laja Gris", source: "Canteras del Borde", ratio: 30 },
      { name: "Biopolímero de Linaza", source: "Savia Vegetal", ratio: 20 }
    ],
    carbonOffset: "-18.3 Ton CO₂",
    description: "Construido suspendido sobre los bordes de la cascada secundaria. Conforma una estructura circular que capta la humedad de las brisas del cañón forestal y la filtra de manera natural para el estanque comunal.",
    blueprintImage: "https://lh3.googleusercontent.com/aida-public/AB6AXuBnpzMTHOO_qRt-0ibUT9j3caM1p1XLl0esvymt0rgEUVcUguV-20xdCj5NViuNksQwYKG5OWxvGOQt0NkrbJcb80SL-SwfZdH2Y1Qn85uTvDGUMhgZuRI3WORM672_xB84QBevfx6eFa_0hqRcmWZiAk_UcU5ZrPvj0eRO9mnP6j8Tymqref4-wM6Pu8ZDeIgypcQlLqnbLJhjW3aBjHA47C1KBUlFaqwLX8kZE1l3SVamYgDmBpekA4AlnfnXfwvNgK3yeZOt1rY"
  },
  {
    id: "pavilion-3",
    name: "Santuario Nocturno",
    volume: "560 m³",
    height: "9.0 m",
    materials: [
      { name: "Ladrillo de Micelio Sólido", source: "Biofabricación Comunal", ratio: 55 },
      { name: "Bambú Nativo Colihue", source: "Quebradas Templadas", ratio: 30 },
      { name: "Resina Bioluminiscente", source: "Cultivos de Algas", ratio: 15 }
    ],
    carbonOffset: "-32.1 Ton CO₂",
    description: "La estructura más profunda del bosque. Paredes orgánicas cultivadas con hongos miceliales aíslan acústicamente el templo, logrando un silencio absoluto. El interior es iluminado únicamente por líquenes luminosos.",
    blueprintImage: "https://lh3.googleusercontent.com/aida-public/AB6AXuClcnNjKTA3ZR9f27S0AQq6cYNbPjJp2Qpx370uq_kY8PpO3BvEt97gxATevo-89dJNkQ6vSASH9uTjNpl2snM4zfCFedp1SPWiu0enkXHbNpTwStoasc4BvqAAV1Zy6z6aJPGcOpK4Alzv1G908pWJbGUJcAc6-jIUmbEpNli-P_5gI2_keNnw-vtzJMlloQRCP5MOeYaIQrX63yNOqPc8petCrpMexqntiTJSkq6F8P4buPCyxMJwp955zQyJdcUtETpkoLeRg4Y"
  }
];

export default function GaleriaSenda() {
  const [selectedPavilion, setSelectedPavilion] = useState<Pavilion>(PAVILIONS_DATA[0]);
  const [depthSlider, setDepthSlider] = useState(50); // slider for cross sectional scan
  
  // Press Kit downloader state
  const [selectedAssets, setSelectedAssets] = useState<string[]>([
    "high-res-photos",
    "structural-plans"
  ]);
  const [downloadStep, setDownloadStep] = useState<"idle" | "compiling" | "ready" | "done">("idle");
  const [complilingProgress, setCompilingProgress] = useState(0);

  const scanRef = useRef<HTMLDivElement>(null);
  const kitRef = useRef<HTMLDivElement>(null);

  const toggleAsset = (assetId: string) => {
    if (selectedAssets.includes(assetId)) {
      setSelectedAssets(selectedAssets.filter((id) => id !== assetId));
    } else {
      setSelectedAssets([...selectedAssets, assetId]);
    }
  };

  const handleStartCompiling = () => {
    if (selectedAssets.length === 0) {
      alert("Por favor selecciona al menos un archivo para compilar.");
      return;
    }
    setDownloadStep("compiling");
    setCompilingProgress(0);
    const interval = setInterval(() => {
      setCompilingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setDownloadStep("ready");
          return 100;
        }
        return prev + 10;
      });
    }, 150);
  };

  const handleDownloadComplete = () => {
    setDownloadStep("done");
    setTimeout(() => {
      setDownloadStep("idle");
    }, 2000);
  };

  const scrollToSection = (ref: React.RefObject<HTMLDivElement | null>) => {
    ref.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div id="screen-senda" className="min-h-screen text-forest-50 select-none pb-24">
      {/* Intro visual header */}
      <div className="max-w-6xl mx-auto px-6 pt-8 pb-12">
        <div className="text-center md:text-left max-w-3xl mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-forest-900 border border-bionic-green/20 rounded-full text-[10px] font-mono tracking-widest text-[#34d399] uppercase mb-4">
            <Landmark className="w-3.5 h-3.5" />
            Galería Fotográfica y Arquitectura
          </div>
          <h1 
            id="senda-heading"
            className="text-4xl md:text-6xl font-serif font-black tracking-tight text-white mb-4 uppercase"
          >
            Senda de Arquitectura
          </h1>
          <p className="text-forest-100 font-sans font-light text-sm md:text-base leading-relaxed">
            Explora la maqueta constructiva de la reserva. Cada espacio ha sido erigido protegiendo la biodiversidad, utilizando materiales locales biodegradables y respetando los límites forestales.
          </p>

          <div className="flex flex-wrap gap-4 mt-6">
            <button
              id="btn-trigger-estudio-volumetrico"
              onClick={() => scrollToSection(scanRef)}
              className="px-5 py-2.5 bg-forest-800 hover:bg-forest-600 border border-bionic-green/40 text-bionic-green hover:text-white rounded-full text-xs font-semibold tracking-wider transition-all cursor-pointer uppercase"
            >
              Estudio Volumétrico
            </button>
            <button
              id="btn-trigger-press-kit"
              onClick={() => scrollToSection(kitRef)}
              className="px-5 py-2.5 bg-transparent hover:bg-forest-900/40 border border-forest-600/40 hover:border-forest-200 text-forest-100 hover:text-white rounded-full text-xs font-semibold tracking-wider transition-all cursor-pointer uppercase"
            >
              Descargar Kit de Prensa
            </button>
          </div>
        </div>

        {/* Bento Grid layout containing photography assets */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          {/* Grid Panel 1 (Large Image: Maqueta Detail) */}
          <div className="md:col-span-7 bg-forest-900/20 border border-forest-800/60 p-5 rounded-3xl relative overflow-hidden group">
            <div className="relative h-64 md:h-96 rounded-2xl overflow-hidden border border-forest-805 bg-moss-950">
              <img 
                id="bento-img-large"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuACElVhUqYrUqJpCy0B3lm4ERp5B5G0JmgL8G3Pl_b48X8YnVGCr-hW-easfp0XOQc3WBrkX2JAwP7XZoUMG0_csVxk_U0vDhzEO0aXDU6iIH_3T-tljlbyRnc12zCUrTs0m-oTPjayFAtxoqyEmtsff1C24xTAo8ovQENJZuELyNxQNd3XTzy465WZO6mrlSbG51TB4BLg82b37Z1hk60zMmfHmGJsMU_ziQvjpjSI2pH0ZlE29LFOOVYfm2pdvvXvpHF0LEM9K9Q" 
                alt="Detalle Estructura Madera Reserva" 
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-700" 
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-4 left-4 bg-moss-950/95 border border-bionic-green/40 px-3 py-1 rounded text-[9px] font-mono tracking-widest text-[#34d399] uppercase">
                Foco Constructivo: Mimbre Trenzado
              </span>
            </div>
            <div className="mt-4 text-left">
              <span className="text-[10px] font-mono text-bionic-amber uppercase tracking-wider block">// Acércamiento Volumétrico</span>
              <h3 className="font-serif font-bold text-white text-lg mt-0.5">Soporte Capilar Integrado</h3>
              <p className="text-xs text-forest-100 font-sans mt-1">
                La técnica de doble curvatura de nuestros artesanos locales permite tejer el mimbre para distribuir uniformemente el esfuerzo estructural sin recurrir a clavos metálicos nocivos.
              </p>
            </div>
          </div>

          {/* Grid Panel 2 (Circular/Detail section inside) */}
          <div className="md:col-span-5 grid grid-rows-2 gap-6">
            
            {/* Top row: Circle Detailed focus view */}
            <div className="bg-forest-900/20 border border-forest-800/60 p-5 rounded-3xl flex flex-col justify-between group">
              <div className="flex items-center gap-4">
                {/* Circular image display */}
                <div className="w-24 h-24 rounded-full border-2 border-bionic-amber overflow-hidden shrink-0 shadow-xl bg-moss-950">
                  <img 
                    id="bento-img-circular"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuDHyi98cna5XQ1XKFVk2NAHxucU6gzjdA7iUmdMqTZMEUig3bNX6egw4yRN57ZvAO67k4vnu4lf5gc2wlqPWMHV-z6Oq8t52-bscoseKUtVBV9KfKrMUS5-VEOBMNYrJRLrDGZxdPtCxyJyre1FimgNiluPEn2AtuhIo3zSTx0zFz6Jzj_4ZDHUw4is519PscjqUCD9BAim1uM4MmyRkbDbjcr5Vl60UZXxbLKCP8sWHc8EYjcWkBINt8NSfYtcbmkritRbnOKEFkI" 
                    alt="Canal Circular de Alerce" 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="text-left">
                  <span className="text-[9px] font-mono text-bionic-green uppercase tracking-widest block">Registro N_K14</span>
                  <h4 className="font-serif font-black text-white uppercase text-md">Anillo Geométrico</h4>
                  <p className="text-[11px] text-forest-100 font-sans mt-1">
                    Análisis constructivo de la sección circular del estanque de las cascadas bajas, asumiendo dinámicas de filtración de sedimentos.
                  </p>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-forest-800/40 flex justify-between items-center text-[10px] font-mono">
                <span className="text-forest-200">DIÁMETRO CORTE</span>
                <span className="text-bionic-amber">12.5 METROS NETA</span>
              </div>
            </div>

            {/* Bottom row: Full maqueta architectural perspective */}
            <div className="bg-forest-900/20 border border-forest-800/60 p-5 rounded-3xl flex flex-col justify-between group">
              <div className="relative h-32 rounded-2xl overflow-hidden border border-forest-850 bg-moss-950">
                <img 
                  id="bento-img-maqueta"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuA5z6PRa-VHXvZWZLUHcG6AQNZMRbpfhThgsZcd-tE9VMnmmUtTVhYe-N21xwO7KZgoSPbhGy9c6ZtwRsHXE7c8QiqiI6ioEOPNq8A5c5an-__JhA1pCpjHHpZXq1TWlzCfev1HtgyYJLfseQiAm3W25UfLQHRrbh3Rslcz4K4RgvInYJqvtpPWQRXGC6j1qeHugXIawFaexSmIdziXCZyBc9F-X2AcKzpANdCwjMzls6Qe2BRWFGsS8v-_Xx3Wke3pLh7GEzealLo" 
                  alt="Vista Terrestre Maqueta Completa" 
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-700" 
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="mt-4 flex justify-between items-center">
                <div className="text-left">
                  <h4 className="text-xs font-serif font-bold text-white uppercase">Perspectiva Tridimensional</h4>
                  <span className="text-[9px] font-sans text-forest-100">Vista isométrica fotorrealista de los nexos de mimbre.</span>
                </div>
                <button
                  id="btn-ir-volumetrico-direct"
                  onClick={() => scrollToSection(scanRef)}
                  className="p-1 px-2.5 bg-forest-800 border border-forest-700 hover:border-bionic-green text-[9px] font-mono text-bionic-green tracking-wider rounded-md uppercase"
                >
                  Analizar volumen
                </button>
              </div>
            </div>

          </div>

        </div>
      </div>

      {/* SECTION: ESTUDIO VOLUMÉTRICO (Architectural scan of Pavilions) */}
      <div 
        id="volumetric-scanner-section"
        ref={scanRef}
        className="max-w-6xl mx-auto px-6 border-t border-forest-800/50 pt-16 mb-20"
      >
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[10px] font-mono text-bionic-green uppercase tracking-widest block mb-1">
            // Ingeniería de Sostenibilidad Volumétrica
          </span>
          <h2 className="text-3xl font-serif font-bold text-white uppercase">
            Estudio Volumétrico Interactivo
          </h2>
          <p className="text-xs text-forest-100 font-sans mt-2 leading-relaxed">
            Interpola los parámetros físicos de cada pabellón ecológico y analiza el asombroso secuestro de carbono derivado del uso exclusivo de biomasa de alerce y micelio celular silviculturado.
          </p>
        </div>

        {/* Picker for different pavilions */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
          {PAVILIONS_DATA.map((pav) => (
            <button
              id={`pavilion-picker-${pav.id}`}
              key={pav.id}
              onClick={() => setSelectedPavilion(pav)}
              className={`px-5 py-3 rounded-full text-xs font-bold tracking-wider transition-all cursor-pointer ${
                selectedPavilion.id === pav.id 
                  ? "bg-bionic-green border border-bionic-green text-moss-950 font-black shadow-lg" 
                  : "bg-forest-900/50 border border-forest-800/80 text-forest-100 hover:text-white"
              }`}
            >
              {pav.name}
            </button>
          ))}
        </div>

        {/* Layout details of selected pavilion */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Volumetrics Scan Data */}
          <div className="lg:col-span-6 bg-forest-900/10 border border-forest-800/80 p-6 md:p-8 rounded-3xl flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className="text-[10px] font-mono text-bionic-amber uppercase tracking-wider block">Inspección de Obra</span>
                  <h3 className="text-2xl font-serif font-black text-white uppercase leading-tight mt-0.5">{selectedPavilion.name}</h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-forest-200 uppercase block">Amortiguación Biológica</span>
                  <span className="text-sm font-mono text-bionic-green font-bold block mt-0.5">{selectedPavilion.carbonOffset}</span>
                </div>
              </div>

              {/* Volume scale display */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="p-4 bg-moss-950/80 border border-forest-800 rounded-2xl">
                  <span className="text-[9px] font-mono text-forest-200 uppercase block">Volumen Interior</span>
                  <span className="text-xl font-mono text-white font-black block mt-0.5">{selectedPavilion.volume}</span>
                </div>
                <div className="p-4 bg-moss-950/80 border border-forest-800 rounded-2xl">
                  <span className="text-[9px] font-mono text-forest-200 uppercase block">Altura Máxima Altura</span>
                  <span className="text-xl font-mono text-white font-black block mt-0.5">{selectedPavilion.height}</span>
                </div>
              </div>

              {/* Materials summary ratios */}
              <div className="space-y-4 mb-6">
                <span className="text-[10px] font-mono text-bionic-green uppercase tracking-wider block">Fórmula de Biocomponentes Locales</span>
                {selectedPavilion.materials.map((m, idx) => (
                  <div key={idx} className="bg-moss-950/40 border border-forest-850/40 rounded-xl p-3 flex justify-between items-center text-xs">
                    <div>
                      <span className="font-sans font-bold text-white block">{m.name}</span>
                      <span className="text-[9px] font-mono text-forest-200 block mt-0.5">Origen: {m.source}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono text-bionic-amber font-bold">{m.ratio}%</span>
                      <div className="w-16 bg-forest-900 h-1.5 rounded-full mt-1 overflow-hidden border border-forest-850">
                        <div className="bg-bionic-amber h-full" style={{ width: `${m.ratio}%` }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <p className="text-xs text-forest-100 font-sans leading-relaxed">
                {selectedPavilion.description} El diseño arquitectónico promueve el confort higrotérmico pasivo, reduciendo la huella hídrica y promoviendo la simbiosis.
              </p>
            </div>

            {/* Depth slider tool simulation */}
            <div className="mt-8 pt-6 border-t border-forest-800/40">
              <div className="flex justify-between items-center text-[10px] font-mono text-bionic-green mb-2 uppercase">
                <span>Scanner de Profundidad Isométrico</span>
                <span>Foco: {depthSlider}% Z-axis</span>
              </div>
              <input 
                id="slider-depth-volumetric"
                type="range" 
                min="0" 
                max="100" 
                value={depthSlider}
                onChange={(e) => setDepthSlider(parseInt(e.target.value))}
                className="w-full accent-bionic-green bg-moss-950 rounded-lg cursor-pointer h-1"
              />
              <span className="text-[9px] text-forest-200 block mt-1.5 font-sans leading-tight">
                Mueve el deslizador para proyectar los niveles volumétricos y el traslape de vigas de madera.
              </span>
            </div>
          </div>

          {/* Holographic interactive render */}
          <div className="lg:col-span-6 bg-moss-950 border border-forest-800/80 p-6 rounded-3xl relative overflow-hidden flex flex-col justify-between">
            <div className="absolute inset-0 bg-radial from-bionic-amber/5 to-transparent pointer-events-none" />
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Sliders className="w-4 h-4 text-bionic-amber" />
                <span className="text-[10px] font-mono text-bionic-amber uppercase tracking-widest">Render Holográfico Activo</span>
              </div>

              {/* Dynamic blueprint rendering representing architectural mockup */}
              <div className="border border-forest-850 h-72 rounded-2xl relative overflow-hidden flex items-center justify-center bg-[#070b09]">
                <img 
                  id="pavilion-blueprint-img"
                  src={selectedPavilion.blueprintImage}
                  alt={selectedPavilion.name}
                  className="w-full h-full object-cover opacity-60"
                  referrerPolicy="no-referrer"
                />
                
                {/* Simulated scan overlay line shifting based on slider */}
                <div 
                  className="absolute left-0 w-full h-0.5 bg-bionic-green shadow-[0_0_10px_#34d399] pointer-events-none transition-all duration-300"
                  style={{ top: `${depthSlider}%` }}
                />

                {/* Micro tech notations */}
                <div className="absolute top-4 right-4 bg-moss-950/90 border border-forest-800 px-2 py-1 rounded text-[8px] font-mono text-forest-200">
                  REF_BLUEPRINT_X{selectedPavilion.id.slice(-1)}
                </div>
                
                <div className="absolute bottom-4 left-4 bg-moss-950/90 border border-bionic-amber/40 px-2.5 py-1 rounded-md text-[9px] font-mono text-bionic-amber uppercase">
                  Carbon offset verified
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-forest-900/40 rounded-xl border border-forest-850/40 text-xs flex justify-between items-center font-sans text-forest-100">
              <span>Optimización biofílica auditada por comité indígena local. (Reforestación compensada)</span>
              <Star className="w-4 h-4 text-bionic-amber fill-bionic-amber shrink-0 ml-4 animate-bounce" />
            </div>
          </div>

        </div>
      </div>

      {/* SECTION: Descargar Kit de Prensa (Interactive Bundle Compiler tool) */}
      <div 
        id="press-kit-compiler-section"
        ref={kitRef}
        className="max-w-6xl mx-auto px-6 border-t border-forest-800/50 pt-16"
      >
        <div className="bg-forest-900/20 border border-forest-800/60 rounded-3xl p-6 md:p-10 relative overflow-hidden">
          <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-bionic-green/10 rounded-full blur-3xl" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-6 space-y-6">
              <div>
                <span className="text-[10px] font-mono text-bionic-amber uppercase tracking-wider block">// Difusión Colectiva</span>
                <h3 className="text-3xl font-serif font-black text-white uppercase leading-none mt-1">Descargar Kit de Prensa</h3>
                <p className="text-xs text-forest-100 font-sans mt-3 leading-relaxed">
                  Compila un paquete oficial que contiene esquemas isométricos vectoriales de los templos, paletas de biomateriales y reportes bioquímicos completos para compartir en asambleas libres.
                </p>
              </div>

              {/* Items checklist */}
              <div className="space-y-2">
                <button 
                  id="checklist-photos"
                  onClick={() => toggleAsset("high-res-photos")}
                  className="w-full flex items-center justify-between p-3.5 bg-moss-950 border border-forest-800 rounded-xl hover:border-bionic-green/40 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <CheckSquare className={`w-5 h-5 ${selectedAssets.includes("high-res-photos") ? "text-bionic-green" : "text-forest-600"}`} />
                    <div>
                      <span className="text-xs font-bold text-white block uppercase">Fotografías de Alta Fidelidad</span>
                      <span className="text-[9px] font-mono text-forest-200 block">3 Archivos JPG (Vista aérea, cúpula y cascadas claros)</span>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono text-forest-200">12.8 MB</span>
                </button>

                <button 
                  id="checklist-blueprints"
                  onClick={() => toggleAsset("structural-plans")}
                  className="w-full flex items-center justify-between p-3.5 bg-moss-950 border border-forest-800 rounded-xl hover:border-bionic-green/40 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <CheckSquare className={`w-5 h-5 ${selectedAssets.includes("structural-plans") ? "text-bionic-green" : "text-forest-600"}`} />
                    <div>
                      <span className="text-xs font-bold text-white block uppercase">Planos de Construcción Vectorial</span>
                      <span className="text-[9px] font-mono text-forest-200 block">Formatos SVG/DXF (Pabellón Origen, Anillo Cúpula)</span>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono text-forest-200">22.4 MB</span>
                </button>

                <button 
                  id="checklist-biodiversity"
                  onClick={() => toggleAsset("biodiversity-audits")}
                  className="w-full flex items-center justify-between p-3.5 bg-moss-950 border border-forest-800 rounded-xl hover:border-bionic-green/40 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <CheckSquare className={`w-5 h-5 ${selectedAssets.includes("biodiversity-audits") ? "text-bionic-green" : "text-forest-600"}`} />
                    <div>
                      <span className="text-xs font-bold text-white block uppercase">Informes Moleculares del Micelio</span>
                      <span className="text-[9px] font-mono text-forest-200 block">PDF Abierto (Matriz de nutrientes, escorrentía)</span>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono text-forest-200">4.1 MB</span>
                </button>
              </div>

              <div className="flex items-center gap-2 text-[10px] text-bionic-amber font-mono bg-amber-950/20 border border-bionic-amber/30 p-3 rounded-xl">
                <AlertCircle className="w-4 h-4 text-bionic-amber shrink-0" />
                <span>Licencia Creative Commons: Uso libre reconociendo autoría de la Comuna Corazón.</span>
              </div>
            </div>

            {/* Dynamic compiling side panel */}
            <div className="lg:col-span-6 bg-moss-950 border border-forest-800 rounded-2xl p-6 min-h-[320px] flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-[#34d399] uppercase tracking-wider block mb-2">Compilador de Kit Digital</span>
                <p className="text-xs text-forest-100 font-sans mb-6">
                  Una vez seleccionados tus archivos, presiona compilar para empaquetar tu archivo ZIP listo para descarga ecológica.
                </p>
              </div>

              <div className="flex-1 flex flex-col justify-center py-6">
                <AnimatePresence mode="wait">
                  {downloadStep === "idle" && (
                    <motion.div key="idle" className="text-center space-y-3">
                      <FolderOpen className="w-12 h-12 text-forest-200 opacity-60 mx-auto" />
                      <button
                        id="btn-empacar-kit-prensa"
                        onClick={handleStartCompiling}
                        className="px-6 py-3.5 bg-bionic-green hover:bg-bionic-light text-moss-950 text-xs font-extrabold tracking-wider uppercase rounded-full transition-all inline-flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-950/30"
                      >
                        <Download className="w-4 h-4 text-moss-950" />
                        Compilar Archivo Kit de Prensa
                      </button>
                    </motion.div>
                  )}

                  {downloadStep === "compiling" && (
                    <motion.div key="compiling" className="space-y-4">
                      <div className="flex justify-between text-[11px] font-mono text-bionic-green">
                        <span className="flex items-center gap-1.5">
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Empaquetando isométricas y renders forestales...
                        </span>
                        <span>{complilingProgress}%</span>
                      </div>
                      <div className="w-full bg-forest-900 border border-forest-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-bionic-green h-full" style={{ width: `${complilingProgress}%` }} />
                      </div>
                    </motion.div>
                  )}

                  {downloadStep === "ready" && (
                    <motion.div key="ready" className="text-center space-y-4">
                      <div className="w-12 h-12 rounded-full bg-emerald-950 border border-bionic-green flex items-center justify-center mx-auto text-bionic-green">
                        ✓
                      </div>
                      <div>
                        <p className="text-xs text-white font-bold uppercase tracking-wider">¡Compilación Completa!</p>
                        <p className="text-[10px] text-forest-200 mt-0.5">Archivo listo: ReservaCorazon_KitPrensa.zip</p>
                      </div>
                      <button
                        id="btn-trigger-zip-download"
                        onClick={handleDownloadComplete}
                        className="px-5 py-3 bg-bionic-amber hover:bg-amber-400 text-moss-950 text-xs font-black tracking-wider uppercase rounded-full transition-all inline-flex items-center gap-2 cursor-pointer"
                      >
                        Descargar archivo (.ZIP)
                      </button>
                    </motion.div>
                  )}

                  {downloadStep === "done" && (
                    <motion.div key="done" className="text-center space-y-2 py-4">
                      <p className="text-sm font-serif font-black text-bionic-green uppercase">¡Descarga Iniciada!</p>
                      <p className="text-[10px] text-forest-200">Revisa la carpeta de descargas de tu navegador para acceder a los isométricos.</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="text-[9px] font-mono text-forest-200 pt-3 border-t border-forest-850/60 uppercase">
                Archivos elegidos: {selectedAssets.length} | Capacidad total estimada: {(selectedAssets.includes("high-res-photos") ? 12.8 : 0) + (selectedAssets.includes("structural-plans") ? 22.4 : 0) + (selectedAssets.includes("biodiversity-audits") ? 4.1 : 0)} MB
              </div>
            </div>

          </div>

        </div>
      </div>

    </div>
  );
}
